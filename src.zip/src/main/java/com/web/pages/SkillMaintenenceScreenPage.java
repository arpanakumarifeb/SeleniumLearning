package com.web.pages;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.common.Common;
import com.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class SkillMaintenenceScreenPage {


	SoftAssert softAssert = new SoftAssert();
	
	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	@FindBy(xpath = "(//span[contains(text(),'TRN_SKILL_MAINTENANCE')])[2]")
	private WebElement PageTitle;
	
	//add
	@FindBy(xpath = "(//div[@class='ButtonList Right  Count3']//button[@value='ADD'])[1]")
	private WebElement addBtn;

	@FindBy(xpath = ".//td[@class='Control fc_Name']//input")
	private WebElement addPopUpEmployeeNameInput;
	
	@FindBy(xpath = ".//td[@class='Control fc_ID']/input")
	private WebElement addPopUpEmployeeIDInput;

	@FindBy(xpath ="(//div[@class='FORM_FOOT'])[3]//button")
	private WebElement addBtnPopUpWindow;
	
	// modify	
	
	@FindBy(xpath = "(//div[@class='ButtonList Right  Count3']//button[@value='MODIFY'])[1]")
	private WebElement modifyBtn;
	
	@FindBy(xpath = ".//td[@class='Control fc_Name']//input")
	private WebElement modifyPopUpEmployeeNameInput;
	
	@FindBy(xpath ="(//div[@class='FORM_FOOT'])[3]//button")
	private WebElement modifyBtnPopUpWindow;
	
	// delete
	@FindBy(xpath = "(//div[@class='ButtonList Right  Count3']//button[@value='DELETE'])[1]")
	private WebElement deleteBtn;
	
	@FindBy(xpath = ".//td[@class='Control fc_Name']//span")
	private WebElement deletePopUpScreen;	
	
	//
	@FindBy(xpath =".//div[@class='FORM_FOOT']//span[text()='YES']")
	private WebElement yesBtn;
	
	
	@FindBy(xpath = ".//tbody[contains(@id,'content_ctl03_ctl00_G0_G11_G13_BC')]/tr[not(contains(@class,'Dummy'))]//span[@class='display']")
	private List <WebElement> skillList;
	
	@FindBy(xpath = ".//tbody[contains(@id,'content_ctl03_ctl00_G0_G11_G13_BC')]/tr[not(contains(@class,'Dummy'))]//label")
	private List <WebElement> skillLabelList;

	
	

	private WebDriver driver;
	private Common common;

	public SkillMaintenenceScreenPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
		new SoftAssert();

	}
	/**
	 * Method To validate validateEmpScreen
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public void validateEmpScreen(String title, String ScreenshotRequire) throws InterruptedException{
		try
		{
			System.out.println("validateEmpScreen function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			Common.isElementDisplayed(driver, PageTitle, IConstants.HIGH_WAIT_TIME);
			Assert.assertEquals(PageTitle.getText().trim().toLowerCase(),title.toLowerCase(),"Verified - Employee Screen is displayed successfuly correctly ");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Employee Screen is not displayed successfuly:: "+title+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To click add button
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public void clickAddBtn(String ScreenshotRequire) throws InterruptedException{
		try
		{
			System.out.println("clickAddBtn function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.waitForElementToBeDisplayed(addBtn, IConstants.MEDIUM_WAIT_TIME);
			Common.isElementDisplayed(driver, addBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(addBtn, "addBtn");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Clicked on Add Button"+common.captureScreenshot(ScreenshotRequire) );
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			WebTestCase.getTest().log(LogStatus.FAIL,exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	/**
	 * Method To validate add employee skill
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public String addEmployeeSkillFunction(String ScreenshotRequire) throws InterruptedException{
		boolean flag=false;
		String employeeSkillName=null;
		try
		{
			// generate random value
			int value= common.generateRandomIntIntRange(0, 100);
			employeeSkillName= "Skill"+value;
			System.out.println("addEmployeeSkillFunction function" + employeeSkillName);
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			Common.isElementDisplayed(driver, addPopUpEmployeeNameInput, IConstants.HIGH_WAIT_TIME);
			common.setObjectValue(addPopUpEmployeeNameInput, "addPopUpName", employeeSkillName);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified -Add new Employee name Arpana");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			
			Common.isElementDisplayed(driver, addPopUpEmployeeNameInput, IConstants.HIGH_WAIT_TIME);
			//addPopUpEmployeeIDInput.clear();
			
			Common.isElementDisplayed(driver, addBtnPopUpWindow, IConstants.HIGH_WAIT_TIME);
			common.waitForElementToBeDisplayed(addBtnPopUpWindow, IConstants.MEDIUM_WAIT_TIME);
			common.clickOnObject(addBtnPopUpWindow, "addBtnPopUpWindow");
			Thread.sleep(10000);
			int list= skillList.size();
			
			for(int i=0;i<list;i++) {
				if(skillList.get(i).getText().contains(employeeSkillName)) {
					flag=true;
					break;
				}else {
					flag=false;
				}
			}
			if(flag) {
				System.out.println("Verified - employee skill get added:: " + employeeSkillName);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - employee skill get added:: " + employeeSkillName+common.captureScreenshot(ScreenshotRequire));
			}else {
				System.out.println("Verified - employee skill not get added:: " + employeeSkillName);
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - employee skill not get added:: " + employeeSkillName+common.captureScreenshot(ScreenshotRequire));
				employeeSkillName=null;
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return employeeSkillName;
	}
	
	/**
	 * Method To validate modify employee skill
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public String modifyEmployeeSkillFunction(String employeeSkillName, String ScreenshotRequire) throws InterruptedException{
		boolean flag=false;
		String skillName= null;
		String newSkillName=null;
		try
		{
			System.out.println("modifyEmployeeSkillFunction function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			int list= skillList.size();
			if(list>0) {
				for(int i=0;i<list;i++) {
					if(skillList.get(i).getText().equals(employeeSkillName)) {
						common.clickOnObject(skillLabelList.get(i), "SkillElement");
						common.clickOnObject(modifyBtn, "modifyBtn");
						Thread.sleep(5000);
						skillName= modifyPopUpEmployeeNameInput.getAttribute("value").trim();
						newSkillName= skillName+"Modify";
						common.setObjectValue(modifyPopUpEmployeeNameInput, "modifyPopUpEmployeeNameInput", newSkillName);
						Thread.sleep(5000);
						Common.isElementDisplayed(driver, modifyBtnPopUpWindow, IConstants.HIGH_WAIT_TIME);
						common.clickOnObject(modifyBtnPopUpWindow, "modifyBtnPopUpWindow");
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS,"modified with new Skill:: "+newSkillName+ common.captureScreenshot(ScreenshotRequire));
						common.clickOnObject(yesBtn, "yesBtn");
						Thread.sleep(5000);
						break;
					}
				}
			}
			for(int i=0;i<list;i++) {
				if(skillList.get(i).getText().equals(newSkillName)) {
					flag=true;
					break;
				}else {
					flag=false;
				}
			}
			if(flag) {
				System.out.println("Verified - employee skill get modified to " + newSkillName);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - employee skill get modified to " + newSkillName+common.captureScreenshot(ScreenshotRequire));
			}else {
				newSkillName=null;
				System.out.println("Verified - employee skill not modified to " + newSkillName);
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - employee skill not get modified:: " + newSkillName+common.captureScreenshot(ScreenshotRequire));
				
			}
			
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return newSkillName;
	}
	
	
	/**
	 * Method To validate deleteEmployeeSkillFunction
	 * @author Arpana
	 * @throws InterruptedException
	 * @param title
	 */

	@SuppressWarnings("static-access")
	public boolean deleteEmployeeSkillFunction(String modifySkillName,String ScreenshotRequire) throws InterruptedException{
		boolean flag=false;
		String skillName= null;
		try
		{
			System.out.println("deleteEmployeeSkillFunction function");
			common.switchToFrame(By.xpath(iframepage), IConstants.MEDIUM_WAIT_TIME);
			int list= skillList.size();
			if(list>0) {
				for(int i=0;i<list;i++) {
					if(skillList.get(i).getText().equals(modifySkillName)) {
						common.clickOnObject(skillLabelList.get(i), "SkillElement");
						common.clickOnObject(deleteBtn, "deleteBtn");
						Thread.sleep(5000);
						skillName= deletePopUpScreen.getText().trim();
						Common.isElementDisplayed(driver, modifyBtnPopUpWindow, IConstants.HIGH_WAIT_TIME);
						common.clickOnObject(modifyBtnPopUpWindow, "modifyBtnPopUpWindow");
						Thread.sleep(5000);
						WebTestCase.getTest().log(LogStatus.PASS,"Delete the Skill::" + skillName + common.captureScreenshot(ScreenshotRequire));
						
						common.clickOnObject(yesBtn, "yesBtn");
						Thread.sleep(5000);
						break;
					}
				}
			}
			
			for(int i=0;i<list;i++) {
				if(skillList.get(i).getText().equals(modifySkillName)) {
					flag=false;
				}else {
					flag=true;
					break;
				}
			}
			if(flag) {
				System.out.println("Verified - employee skill get deleted " + modifySkillName);
				WebTestCase.getTest().log(LogStatus.PASS, "Verified - employee skill get deleted " + skillName+common.captureScreenshot(ScreenshotRequire));
			}else {
				System.out.println("Verified - employee skill not deleted " + modifySkillName);
				WebTestCase.getTest().log(LogStatus.FAIL, "Verified - employee skill not get deleted " + skillName+common.captureScreenshot(ScreenshotRequire));
				
			}
			
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}


}

