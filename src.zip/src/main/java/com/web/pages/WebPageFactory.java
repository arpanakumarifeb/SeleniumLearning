package com.web.pages;

import org.openqa.selenium.WebDriver;

public class WebPageFactory {

	/**
	 * @return the elxLogin
	 */
	public AprisoLoginPage getElxLogin() {
		return elxLogin;
	}
	/**
	 * @param elxLogin the elxLogin to set
	 */
	public static void setElxLogin(AprisoLoginPage elxLogin) {
		WebPageFactory.elxLogin = elxLogin;
	}
	private static AprisoLoginPage elxLogin=null;
	
	/**
	 * @return the aprisoCommon
	 */
	public AprisoCommonPage getAprisoCommonPage() {
		return aprisoCommonPage;
	}
	/**
	 * @param AprisoCommonPage the AprisoCommonPage to set
	 */
	public static void setAprisoCommon(AprisoCommonPage aprisoCommonPage) {
		WebPageFactory.aprisoCommonPage = aprisoCommonPage;
	}
	private static AprisoCommonPage aprisoCommonPage=null;
	
	/**
	 * @return the workAreaPage
	 */
	public WorkAreaSelectionPage getWorkAreaPage() {
		return workAreaPage;
	}
	/**
	 * @param workAreaPage the workAreaPage to set
	 */
	public static void setWorkAreaPage(WorkAreaSelectionPage workAreaPage) {
		WebPageFactory.workAreaPage = workAreaPage;
	}
	private static WorkAreaSelectionPage workAreaPage= null;

	/**
	 * @return the searchPage
	 */
	
	
	public SearchPage getSearchPage() {
		return searchPage;
	}
	/**
	 * @param searchPage the searchPage to set
	 */
	public static void setSearchPage(SearchPage searchPage) {
		WebPageFactory.searchPage = searchPage;
	}
	private static SearchPage searchPage=null;
	
	
	
	
	public WebPageFactory(WebDriver driver) {
		instance(driver);
	}
	public static void instance(WebDriver driver){ 
			elxLogin = new AprisoLoginPage(driver);
			searchPage = new SearchPage(driver);
			workAreaPage = new WorkAreaSelectionPage(driver);
			aprisoCommonPage = new AprisoCommonPage(driver);
			skillMaintenenceScreen=new SkillMaintenenceScreenPage(driver);
	}
	/**
	 * @return the elxskillpallet
	 */
	public SkillMaintenenceScreenPage getSkillMaintenenceScreen() {
		return skillMaintenenceScreen;
	}
	/**
	 * @param elxskillpallet the elxskillpallet to set
	 */
	public static void setMaintenenceScreen(SkillMaintenenceScreenPage skillMaintenenceScreen) {
		WebPageFactory.skillMaintenenceScreen = skillMaintenenceScreen;
	}
	private static SkillMaintenenceScreenPage skillMaintenenceScreen=null;
	
}