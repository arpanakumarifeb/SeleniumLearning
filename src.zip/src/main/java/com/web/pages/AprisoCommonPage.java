package com.web.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.common.Common;
import com.core.util.PropertyElementReader;
import com.dto.handler.EnvirnomentHandler;
import com.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class AprisoCommonPage {

	@SuppressWarnings("static-access")
	private String locale = EnvirnomentHandler.getInstance().getEnvirnoment().getLocale();
	@SuppressWarnings("unused")
	private PropertyElementReader elementReader = PropertyElementReader.getInstance(locale);

	@FindBy(xpath ="//button[@class='ToolButton CREATE_NC_OUTOFCONTEXT T1 ']")
	private WebElement createNCButton;

	@FindBy(xpath ="//li[@title='NCM-020']")
	private WebElement createNCTitle;

	@FindBy(xpath ="//h2[@class='Label FormHead Collapsed']")
	private WebElement NCInfoPageTitle;

	@FindBy(xpath = ".//span[@title='Home']")
	private  WebElement homeIcon	;

	@FindBy(xpath = ".//span[@title='Return']")
	private  WebElement ReturnIcon;

	// alert functionality

	@FindBy(xpath = ".//div[@class='alert-circle']")
	private  WebElement alertCircle;

	@FindBy(xpath = ".//span[@data-flx-literal='ELX_Top5UnacknowledgedAlerts']")
	private  WebElement UnacknowledgedAlertsHeader;

	@FindBy(xpath = ".//tr[@id='TableFirstRow']//following-sibling::tr[1]/td[2]")
	private  WebElement firstAlertMsg;	

	@FindBy(xpath = ".//li[@title='ALT-10']")
	private  WebElement alertScreenHeader;

	@FindBy(xpath = ".//button[@class='ToolButton ACKNOWLEDGE Primary']/span")
	private  WebElement ackbtn;

	@FindBy(xpath = ".//span[@class='apr-title']")
	private  WebElement ackPopupBox;

	@FindBy(xpath = ".//td[@class='Control fc_AlertComment']/textarea")
	private  WebElement ackCommentBox;

	@FindBy(xpath = ".//button[@value='ACKNOWLEDGE']/span")
	private  WebElement ackPopupBtn;

	@FindBy(xpath = ".//div[@class='apr-message-list']")
	private  WebElement errorMsgDiv;

	@FindBy(xpath = ".//div[@class='apr-message-error']")
	private  WebElement errorMsg;









	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";
	String dashboard="//*[@id='DashboardAlert']/div/div/div[1]/a";


	private WebDriver driver;
	private Common common;

	public AprisoCommonPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}



	/**
	 * Method To click Create NC Button
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String clickCreateNCButton(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		System.out.println("inside clickCreateNCButton function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(dashboard),IConstants.LOW_WAIT_TIME);
			Common.isElementDisplayed(driver, createNCButton, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(createNCButton,"createNCButton");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			img=common.captureScreenshot(ScreenshotRequire);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Create Button is clicked successfuly"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	//Order# Verification
	@SuppressWarnings("static-access")
	public void validateCreateNCPageTitle(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		Common.isElementDisplayed(driver, createNCTitle, IConstants.LOW_WAIT_TIME);
		driver.switchTo().defaultContent();
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Crete NC page loaded"+ common.captureScreenshot(ScreenshotRequire));
		driver.switchTo().defaultContent();

	}

	@SuppressWarnings("static-access")
	public void validateNCPageTitle(String orderId, String ScreenshotRequire) throws InterruptedException{
		common.switchToFrame(By.xpath(iframepage), IConstants.HIGH_WAIT_TIME);
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		Common.isElementDisplayed(driver, NCInfoPageTitle, IConstants.LOW_WAIT_TIME);
		driver.switchTo().defaultContent();
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Non-Conformity Information page loaded"+ common.captureScreenshot(ScreenshotRequire));
	}

	/**
	 * Method To click Home Icon
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	@SuppressWarnings("static-access")
	public void clickHomeIcon(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside click homeIcon function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.isElementDisplayed(driver, homeIcon, IConstants.LOW_WAIT_TIME);
			Assert.assertTrue(homeIcon.isDisplayed(), "Home Icon not displayed");			
			common.clickOnObject(homeIcon, "homeIcon");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			System.out.println("homeIcon clicked");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Home page is appearing"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	@SuppressWarnings("static-access")
	public void clickReturnIcon(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside click ReturnIcon function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(IConstants.MEDIUM_LOADING_WAIT_TIME);
			common.isElementDisplayed(driver, ReturnIcon, IConstants.HIGH_WAIT_TIME);
			//Assert.assertTrue(ReturnIcon.isDisplayed(), "ReturnIcon Icon not displayed");			
			common.clickOnObject(ReturnIcon, "ReturnIcon");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			System.out.println("ReturnIcon clicked");
			WebTestCase.getTest().log(LogStatus.INFO,"ReturnIcon clicked");
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	//click alert bell icon 
	@SuppressWarnings("static-access")
	public void clickOnAlert(String ScreenshotRequire) throws InterruptedException{
		try{
			System.out.println("inside clickAlertAndVerifyFunctionality function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			common.isElementDisplayed(driver, alertCircle, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(alertCircle, "alertCircle");
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on alert Circle bell icon"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("alertCircle clicked");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			common.isElementDisplayed(driver, UnacknowledgedAlertsHeader, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(firstAlertMsg, "firstAlertMsg");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on first alert message");
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
	}

	// verify alert functionalities
	@SuppressWarnings("static-access")
	public boolean verifyAlertFunctionalities(String ScreenshotRequire) throws InterruptedException{
		boolean flag=false;
		try{
			System.out.println("inside verifyAlertFunctionalities function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			common.isElementDisplayed(driver, alertScreenHeader, IConstants.HIGH_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Alert Screen loaded successfully"+ common.captureScreenshot(ScreenshotRequire));
			System.out.println("Alert Screen loaded");
			common.isElementDisplayed(driver, ackbtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(ackbtn, "ackbtn");
			WebTestCase.getTest().log(LogStatus.PASS, "Acknowledge button clicked");
			common.isElementDisplayed(driver, ackPopupBox, IConstants.HIGH_WAIT_TIME);
			common.isElementDisplayed(driver, ackCommentBox, IConstants.HIGH_WAIT_TIME);
			common.setObjectValue(ackCommentBox, "ackCommentBox", "Acknowledged");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			WebTestCase.getTest().log(LogStatus.PASS, "Enter Acknowledge comments " + common.captureScreenshot(ScreenshotRequire));
			common.isElementDisplayed(driver, ackPopupBtn, IConstants.HIGH_WAIT_TIME);
			common.clickOnObject(ackPopupBtn, "ackPopupBtn");
			WebTestCase.getTest().log(LogStatus.PASS, "Clicked on Acknowledge popup screen button");
			Thread.sleep(IConstants.MEDIUM_LOADING_WAIT_TIME);
			if(errorMsgDiv.getAttribute("innerHTML").contains("apr-message-error")){
				flag=false;
				WebTestCase.getTest().log(LogStatus.FAIL, "Acknowledge Action unsuccessful, error msg:: " + errorMsg.getText() +  common.captureScreenshot(ScreenshotRequire));
			}else {
				flag=true;
				WebTestCase.getTest().log(LogStatus.PASS, "Acknowledge Action completed successfully");
			}

			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}

}
