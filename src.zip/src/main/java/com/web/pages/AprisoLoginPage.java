package com.web.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.common.Common;
import com.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class AprisoLoginPage {

	@FindBy(xpath = "//h1/name[text()='Welcome to ']")
	//@FindBy(xpath = "//div[@class='heading']/h1")
	private WebElement welcomeTo;

	@FindBy(xpath = "//h2[text()='Log In to DELMIA Apriso Portal' or text()='Standard Login']")
	private WebElement delmiaPortalLogin;

	@FindBy(xpath = "(//h2)[1]")
	private WebElement standardLogin;

	@FindBy(xpath = "//input[@type='text' and @class='PopupInput input']")
	private WebElement userName;
	@FindBy(xpath = "//input[@type='password' and @class='PopupInput input']")
	private WebElement password;
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement login;
	
	@FindBy(xpath = ".//span[@class='toggle-user']")
	private WebElement userIconRight;
	
	@FindBy(xpath = ".//span[@apr-localize='PERSONALIZATION.LOGOUT']")
	private WebElement logout;	
	
	@FindBy(xpath = ".//span[contains(@class,'apr-header-action user default-icon')]")
	private WebElement userIcon;	
	
	@FindBy(xpath = ".//span[contains(@class,'apr-header-action user default-icon')]//li")
	private WebElement userLogout;	

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	private WebDriver driver;
	private Common common;

	public AprisoLoginPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	/**
	 * Method To check login page
	 * @author 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public boolean isWelcomePage(String ScreenshotRequire){
		boolean flag=false;
		try{
			if((driver.findElement(By.xpath(".//div")).getAttribute("innerText").contains("Welcome to "))||(driver.findElement(By.xpath(".//div")).getAttribute("innerText").contains("Log In"))){
				System.out.println("Welcome Page Displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Welcome Page Displayed" + common.captureScreenshot(ScreenshotRequire));
				flag=true;
			}else {
				System.out.println("Welcome Page not Displayed");
				WebTestCase.getTest().log(LogStatus.INFO, "Welcome Page not Displayed" + common.captureScreenshot(ScreenshotRequire));
				flag=false;
			
			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}


	/**
	 * This method is used to click Login To Delmia link.
	 * @Author 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public String clickLoginToDelmia(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{
			Thread.sleep(IConstants.MEDIUM_LOADING_WAIT_TIME);
			Common.isElementDisplayed(driver, delmiaPortalLogin, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(delmiaPortalLogin, "delmiaPortalLogin");
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.HIGH_WAIT_TIME );
			Thread.sleep(IConstants.MEDIUM_LOADING_WAIT_TIME);;
			System.out.println("click Login To Delmia link");
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;

	}

	public String standardLoginsecondex(String ScreenshotRequire) throws AWTException, InterruptedException{
		String img=null;
		img=common.captureScreenshot(ScreenshotRequire);
		try{
			Common.isElementDisplayed(driver, standardLogin, 180);
		
		Assert.assertTrue(standardLogin.isDisplayed(),"Standard Login Not Displayed");
		common.clickOnObject(standardLogin, "standardLogin");
		common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
		Thread.sleep(IConstants.MEDIUM_LOADING_WAIT_TIME);	
		WebTestCase.getTest().log(LogStatus.PASS, "Standard login clicked"+ img);
		System.out.println("standardLogin clicked for other env");
		
		}catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}


	public String standardLogin(String userid, String pass,String status,String ScreenshotRequire) throws AWTException, InterruptedException{
		String img=null;
		try{
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			Common.isElementDisplayed(driver, standardLogin, 180);
			Assert.assertTrue(standardLogin.isDisplayed(),"Standard Login Not Displayed");
			System.out.println("Standard Login button Displayed");
			img=common.captureScreenshot(ScreenshotRequire);
			common.clickOnObject(standardLogin,"standardLogin");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);		
			WebTestCase.getTest().log(LogStatus.PASS, "Standard login clicked"+ img);
			System.out.println("standardLogin clicked");
		}catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error: "+e);
			WebTestCase.getTest().log(LogStatus.FAIL,e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		return img;
	}
	public String loginToElx(String username,String pwd,String ScreenshotRequire) throws InterruptedException{
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("loginToElx function, username, password::  " + username+ "--" +pwd);
		try{
			Common.isElementDisplayed(driver, userName, 180);
			common.setObjectValue(userName, "userName", username);
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			Common.isElementDisplayed(driver, password, 180);
			common.setObjectValue(password, "password", pwd);
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			common.clickOnObject(login, "login");
			Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.SYS_WAIT_TIME);
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:"+e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		return img;
	}
	/**
	 * Methos To Login
	 * @author Chinmay
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public boolean EnterUserDetailsAndPassword(String username, String passWord, String ScreenshotRequire)
			throws IOException {

		if (common.setObjectValue(userName, "username",username) == false) {
			/*ReportLog.writeLogs(driver, userName,
					"username Should enter",
					"username not entered", "Fail");*/

			return false;
		}
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - username entered successfully"+ common.captureScreenshot(ScreenshotRequire));
		if (common.setObjectValue(password, "password",passWord) == false) {
			/*ReportLog.writeLogs(driver, pwd, "Password Should enter",
					"Password not entered", "Fail");
			Assert.assertFalse(false, "Page not loaded");*/

			return false;
		}
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - Password entered successfully"+ common.captureScreenshot(ScreenshotRequire));

		/*ReportLog.writeLogs(driver, pwd, "Password Should enter",
				"Password entered correctly", "Pass");
		 */
		if (common.clickOnObject(login,
				"Login in") == false) {
			/*ReportLog.writeLogs(driver, btnSubmit,
					"Should Click on Login in Button", "Not Clicked on Login in Button", "Fail");*/
			return false;
		}

		/*ReportLog.writeLogs(driver, null,
				"Should Click on Login in Button",
				" Clicked Successfully on Login in button", "Pass");*/
		WebTestCase.getTest().log(LogStatus.PASS, "Verified - login button clicked successfully"+ common.captureScreenshot(ScreenshotRequire));
		return true;

	}
	
	/**
	 * Method To User logout
	 * @author 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public boolean userLogout_1(String ScreenshotRequire){
		boolean flag=false;
		try{
			Common.isElementDisplayed(driver, userIcon, 180);
			Thread.sleep(5000);
			common.clickOnObject(userIcon, "userIcon");
			Thread.sleep(1000);
			common.clickOnObject(userLogout, "userLogout");
			Thread.sleep(5000);
			if(userName.isDisplayed()) {
				WebTestCase.getTest().log(LogStatus.PASS,"User logout succcess" + common.captureScreenshot("true"));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL,"User logout succcess" + common.captureScreenshot("true"));
			}
			
			Thread.sleep(5000);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}
	
	/**
	 * Method To User logout
	 * @author 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public boolean userLogout(String ScreenshotRequire){
		boolean flag=false;
		try{
			Common.isElementDisplayed(driver, userIconRight, 180);
			Thread.sleep(5000);
			common.clickOnObject(userIconRight, "userIconRight");
			Thread.sleep(1000);
			common.clickOnObject(logout, "userIconRight");
			Thread.sleep(5000);
			if(userName.isDisplayed()) {
				WebTestCase.getTest().log(LogStatus.PASS,"User logout succcess" + common.captureScreenshot("true"));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL,"User logout succcess" + common.captureScreenshot("true"));
			}
			
			Thread.sleep(5000);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}
}
