package com.web.pages;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.testng.Assert;

import com.common.Common;
import com.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;
public class WorkAreaSelectionPage {

	@FindBy(xpath = "(//input[@placeholder='Find a screen...'])[1]")
	private WebElement search;

	@FindBy(xpath = "((//input[@placeholder='Find a screen...'])[1]//..//../div/div[2])[1]")
	private WebElement searchItem;

	@FindBy(xpath = ".//li[@title='Employee.SelectWorkArea']")
	private WebElement WorkAreaSelectionTitle;

	@FindBy(xpath = ".//h2[@class='Label FormHead'][1]")
	private WebElement areaHeader;	

	@FindBy(xpath = ".//div[@class='ELX_WORKCENTER']//button[@class='Primary ']/span")
	private List <WebElement> SelectWorkCenter;

	@FindBy(xpath = ".//div[@class='ELX_WORKCENTER']")
	private WebElement workCenter;

	@FindBy(xpath = ".//div[@class='ELX_AREA']//td/button/span")
	private List <WebElement> ELX_AREABtnList;


	@FindBy(xpath = ".//div[@class='ELX_AREA']")
	private WebElement ELX_AREABtn;

	private WebDriver driver;
	private Common common;
	//List<WebElement> text=null;

	String iframepage="//iframe[@class='apr-fullscreen-tab']";
	String toolbox="//div[@class='Toolbox Top Loading']";

	//repair screen

	@FindBy(xpath = ".//li[@title='RPC.SelectWorkArea']")
	private WebElement SelectRPCWorkArea;

	@FindBy(xpath = ".//div[@class='ELX_STATION']//td")
	private WebElement workStation;

	@FindBy(xpath = "//div[@class='ELX_STATION']//td/button/span")
	private List <WebElement> repairSt;




	public WorkAreaSelectionPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}

	/**
	 * Method To click On Line Item
	 * @author Arpana Kumari
	 * @throws InterruptedException 
	 */

	public String clickOnLineItem(String line,String ScreenshotRequire){
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			System.out.println("inside click on: "+ line);
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.elementToBeClickable(By.xpath("//span[contains(text(),'"+line+"')]"), 120);
			String lineDetails= driver.findElement(By.xpath("//span[contains(text(),'"+line+"')]")).getText();
			if(lineDetails.contains(line)){
				common.elementToBeClickable(By.xpath("//span[contains(text(),'"+line+"')]"), 60);
				common.clickOnObject(driver.findElement(By.xpath("//button/span[contains(text(),'"+line+"')]")), line);
				common.waitTillElementDisappears(By.xpath(toolbox),IConstants.LOW_WAIT_TIME);
				WebTestCase.getTest().log(LogStatus.PASS, "Selected:  "+ lineDetails +common.captureScreenshot(ScreenshotRequire));
			}else {
				WebTestCase.getTest().log(LogStatus.FAIL, lineDetails +"Not available, FAIL" +common.captureScreenshot(ScreenshotRequire));
			}
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	public String validatePageTitle(String ScreenshotRequire) throws InterruptedException{
		try
		{	
			System.out.println("inside validate page title function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.waitForElementLoaded(areaHeader, IConstants.LOW_WAIT_TIME);
			Assert.assertTrue(areaHeader.isDisplayed(),  "Work area selection page not displayed");
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - Work area selection page is displayed successfuly"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}

	public String selectWorkCenter(String ScreenshotRequire) throws InterruptedException{

		try{
			System.out.println("inside selectWorkCenter function");

			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.waitForElementLoaded(workCenter, IConstants.LOW_WAIT_TIME);
			JavascriptExecutor js = (JavascriptExecutor)driver; 

			if(SelectWorkCenter.size()>0) {
				if(SelectWorkCenter.size()>1) {
					int WC=Common.generateRandomIntIntRange(0,(SelectWorkCenter.size()-1));
					System.out.println("RandomIntegerNumberlevel1 = "+WC);
					Common.isElementDisplayed(driver, SelectWorkCenter.get(WC), 30);
					String workcenterText=SelectWorkCenter.get(WC).getText();
					common.waitForElementToBeDisplayed(SelectWorkCenter.get(WC), IConstants.LOW_WAIT_TIME);
					js.executeScript("arguments[0].click();", SelectWorkCenter.get(WC));
					//Thread.sleep(15000);
					WebTestCase.getTest().log(LogStatus.PASS, "Select Work Center:"+ workcenterText+common.captureScreenshot(ScreenshotRequire));
				}else {
					js.executeScript("arguments[0].click();", SelectWorkCenter.get(0));
					WebTestCase.getTest().log(LogStatus.PASS, "Select Work Center"+ SelectWorkCenter.get(0).getText()+common.captureScreenshot(ScreenshotRequire));
				}
			}
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.." +exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);	

	}

	@SuppressWarnings("static-access")
	public void validateAreaButtons(HashMap<Integer,String> hmAction, String ScreenshotRequire) throws InterruptedException{
		System.out.println("inside validateActionButtons function");
		try
		{
			common.switchToFrame(By.xpath(iframepage), 120);
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.LOW_WAIT_TIME);
			common.waitForElementLoaded( ELX_AREABtn, 100);
			for(int i=0;i<ELX_AREABtnList.size();i++) {				
				if((ELX_AREABtnList.get(i).getAttribute("innerHTML").toLowerCase().contains(hmAction.get(i+1).toLowerCase()))) {
					System.out.println("Area List:"+ELX_AREABtnList.get(i).getAttribute("innerHTML"));
					WebTestCase.getTest().log(LogStatus.INFO, "Area List:"+(i+1)+"--"+ELX_AREABtnList.get(i).getAttribute("innerHTML"));
				}
			}
			WebTestCase.getTest().log(LogStatus.INFO, "Area Button list validated successfully"+common.captureScreenshot(ScreenshotRequire));
		}
		catch(java.lang.AssertionError e){
			System.out.println("Got Assertion Error:" +e);
			WebTestCase.getTest().log(LogStatus.FAIL,
					e.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e.getMessage());
		}
		catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
		driver.switchTo().defaultContent();
	}

	/**
	 * Method To click On Line Item
	 * @author Arpana
	 * @throws InterruptedException 
	 */

	public String ValidateAreaAndWorkCenter(String[][] hm2,String[][] LineActiveStatus, int rowCount, String ScreenshotRequire){
		String img=common.captureScreenshot(ScreenshotRequire);
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox),IConstants.LOW_WAIT_TIME);
			common.waitForElementLoaded(ELX_AREABtn, IConstants.LOW_WAIT_TIME);
			System.out.println("ValidateAreaAndWorkCenter function");
			WebTestCase.getTest().log(LogStatus.PASS, "Work Center"+ common.captureScreenshot(ScreenshotRequire));
			int i=0;
			for (int j = 0; j < rowCount; j++) {
				for(int p=0;p<LineActiveStatus.length;p++) {
					if(LineActiveStatus[p][0].contains(hm2[j][0])&&LineActiveStatus[p][1].equalsIgnoreCase("Active")) {
						if((ELX_AREABtnList.get(j).getAttribute("innerText").toLowerCase().contains((hm2[j][i]).toLowerCase()))) {
							System.out.println(ELX_AREABtnList.get(j).getAttribute("innerText")+"---"+hm2[j][i]);
							WebTestCase.getTest().log(LogStatus.PASS, "Area Verification of screen and Global file :" +ELX_AREABtnList.get(j).getAttribute("innerText")+"---"+hm2[j][i]);
							common.waitForElementToBeDisplayed(ELX_AREABtnList.get(j), IConstants.LOW_WAIT_TIME);
							common.clickOnObject(ELX_AREABtnList.get(j),ELX_AREABtnList.get(j).getText());
							common.waitTillElementDisappears(By.xpath(toolbox),IConstants.LOW_WAIT_TIME);
							WebTestCase.getTest().log(LogStatus.PASS, "Area Clicked: "+ELX_AREABtnList.get(j).getAttribute("innerText"));
							Thread.sleep(IConstants.HIGH_LOADING_WAIT_TIME);
							common.waitForElementLoaded(workCenter, 100);
							for(int k=0;k<SelectWorkCenter.size();k++) {	
								if((SelectWorkCenter.get(k).getAttribute("innerText").toLowerCase().contains((hm2[j][k+1]).toLowerCase()))) {
									System.out.println(SelectWorkCenter.get(k).getAttribute("innerText")+"---"+hm2[j][k+1]);
									WebTestCase.getTest().log(LogStatus.PASS, "Work Center Verification of screen and Global file:"+SelectWorkCenter.get(k).getAttribute("innerText")+"---"+hm2[j][k+1]+ common.captureScreenshot(ScreenshotRequire));
								}
							}
						}
						break;
					}

				}

			}
			img=common.captureScreenshot(ScreenshotRequire);			
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

	/**
	 * Method To validate RPC WorkArea Page Title
	 * @author Arpana
	 * @throws InterruptedException 
	 */
	public String validateRPCWorkAreaPageTitle(String title, String ScreenshotRequire) throws InterruptedException{
		try
		{	
			System.out.println("inside validateRPCWorkAreaPage Title function");
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.waitForElementLoaded(SelectRPCWorkArea, IConstants.LOW_WAIT_TIME);
			Assert.assertTrue(SelectRPCWorkArea.getText().contains(title),  "RPC Work area selection page not displayed");
			System.out.println("RPCWorkAreaPage Title: "+ title);
			WebTestCase.getTest().log(LogStatus.PASS, "Verified - RPC Work area selection page is displayed successfuly"+ common.captureScreenshot(ScreenshotRequire));
			driver.switchTo().defaultContent();

		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){

			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return common.captureScreenshot(ScreenshotRequire);
	}


	/**
	 * Method To validate RPC WorkArea Page and repair station details
	 * @author Arpana
	 * @throws InterruptedException 
	 */


	public String ValidateRPCWorkCenterAndRepairStation(String[][] hm2,int rowCount, String ScreenshotRequire){
		String img=common.captureScreenshot(ScreenshotRequire);
		System.out.println("ValidateRPCWorkCenterAndRepairStation function");
		try{
			common.switchToFrame(By.xpath(iframepage), IConstants.LOW_WAIT_TIME);	
			common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
			common.waitForElementLoaded(ELX_AREABtn, IConstants.LOW_WAIT_TIME);
			int i=0;
			int repairStcounter=0;
			for (int j = 0; j < SelectWorkCenter.size(); j++) {
				System.out.println(SelectWorkCenter.get(j).getAttribute("innerText")+"---"+hm2[j][i]);
				if((SelectWorkCenter.get(j).getAttribute("innerText").toLowerCase().trim().contains((hm2[j][i]).toLowerCase().trim()))) {
					WebTestCase.getTest().log(LogStatus.PASS, "work center Verification of screen and Global file :" +SelectWorkCenter.get(j).getAttribute("innerHTML")+"---"+hm2[j][i]);
					JavascriptExecutor js = (JavascriptExecutor)driver; 
					js.executeScript("arguments[0].click();", SelectWorkCenter.get(j));
					//common.clickOnObject(SelectWorkCenter.get(j),SelectWorkCenter.get(j).getText());
					common.waitTillElementDisappears(By.xpath(toolbox), IConstants.LOW_WAIT_TIME );
					WebTestCase.getTest().log(LogStatus.PASS, "work center clicked: "+SelectWorkCenter.get(j).getAttribute("innerHTML"));
					HashMap<Integer, String> repairStation = new HashMap<Integer, String>() ;
					for(int p=0;p<hm2[j].length-1;p++) {
						if(hm2[j][p+1]!=null) {
							repairStcounter++;
							repairStation.put(p, hm2[j][p+1]);
						}
					}
					common.waitForElementLoaded(workStation, IConstants.LOW_WAIT_TIME);
					if(workStation.isDisplayed()) {
						common.scrollBottomOfThePage();
						Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
						//Assert.assertEquals(repairSt.size(), repairStcounter,"repair station list is not correct");
						for(int k=0;k<repairSt.size();k++) {	
							if(workStation.getAttribute("innerText").length()>0){
								if(repairStation.containsValue(repairSt.get(k).getText().trim())) {
									if(repairSt.get(k).getText().toLowerCase().trim().contains((hm2[j][k+1]).trim().toLowerCase())) {
										System.out.println(repairSt.get(k).getText()+"************"+hm2[j][k+1]);
										WebTestCase.getTest().log(LogStatus.PASS, "<b>Work repair station available on screen and Global file:"+repairSt.get(k).getText()+"---"+hm2[j][k+1]+"</b>"+ common.captureScreenshot(ScreenshotRequire));
									}else {
										WebTestCase.getTest().log(LogStatus.INFO, "<b>Work repair station Not matching on UI and Global file:"+repairSt.get(k).getText()+"---"+hm2[j][k+1]+"</b>"+ common.captureScreenshot("true"));
									}
								}else {
									System.out.println("work repair station is not available for work center:" + hm2[j][i]);
									WebTestCase.getTest().log(LogStatus.INFO,"<b>work repair station is not available for work center:" + hm2[j][i]+"</b>");
								}
							}
							common.scrollUp();
							Thread.sleep(IConstants.LOW_LOADING_WAIT_TIME);
						}
					}else {
						System.out.println("work repair station is not available for work center:" + hm2[j][i]);
						WebTestCase.getTest().log(LogStatus.INFO,"<b>work repair station is not available for work center:" + hm2[j][i]+"</b>");
					}
				}
			}
			img=common.captureScreenshot(ScreenshotRequire);			
			driver.switchTo().defaultContent();
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error..");
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got  Error.."+ exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;
	}

}
