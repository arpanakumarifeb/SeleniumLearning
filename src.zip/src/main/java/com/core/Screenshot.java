package com.core;

import com.core.util.WriteExcel;
import com.dto.handler.EnvirnomentHandler;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;
import org.testng.annotations.Test;

public class Screenshot extends TestListenerAdapter
{
  private final String ESCAPE_PROPERTY = "org.uncommons.reportng.escape-output";
  private String testName = null;
  private static String timeZone = "GMT+5:30";
  private static SimpleDateFormat sdftime = new SimpleDateFormat("HH:mm:ss a");
  private static volatile WriteExcel we;
  private static volatile int i = 1;
  private static volatile WritableSheet sheet;
  private String group;

  public Screenshot()
  {
    we = WriteExcel.getInstance();

    String filepath = "src/test/resources/Report.xls";
    filepath = System.getProperty("user.dir") + "/" + filepath;
    we.setOutputFile(filepath);
    try {
      sheet = we.getSheet();
    }
    catch (WriteException e) {
      e.printStackTrace();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void onTestFailure(ITestResult tr)
  {
    synchronized (this) {
      System.out.println("value of testname is   " + this.testName);
      System.out.println("MethodCLASS:::" + tr.getMethod().getTestClass());
      System.out.println("MethodNAME:::" + tr.getMethod().getMethodName());
      try
      {
        this.group = Arrays.toString(
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .groups())
          .replace("[", "");

        this.group = this.group.replace("]", "");
        this.testName = tr.getMethod().getMethodName();

        WriteExcel.createContent(sheet, 1, i, this.group);
        WriteExcel.createContent(sheet, 2, i, 
          ((Test)tr.getMethod()
          .getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .testName());

        WriteExcel.createContent(sheet, 3, i, 
          ((Test)tr.getMethod()
          .getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .description());

        WriteExcel.createContent(sheet, 4, i, "Fail");
        WriteExcel.createContent(sheet, 5, i, getDate());
        i += 1;
      }
      catch (Exception e) {
        e.printStackTrace();
      }

      System.out.println("value of testname is in if condition   " + this.testName);
    }

    if (this.testName != tr.getMethod().getMethodName()) {
      Reporter.log("-Failed-", true);
      System.setProperty("org.uncommons.reportng.escape-output", "false");
      EnvirnomentHandler.getInstance(); boolean islocal = EnvirnomentHandler.getEnvirnoment().isLocal();
      if (islocal) {
        WebDriver driver = (WebDriver)tr.getTestContext().getAttribute("driver");
        File file = new File("");
        Calendar lCDateTime = Calendar.getInstance();
        String time = parseUnixTimeToTimeOfDay(lCDateTime.getTimeInMillis()).replace(":", "").replace(" ", "");

        Reporter.log("IN TEST FAILURE METHOD" + time, true);
        try {
          System.out.println(file.getCanonicalPath());
          if (driver != null) {
            File scrFile = (File)((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

            String f = file.getCanonicalPath() + File.separator + "target" + File.separator + "surefire-reports" + File.separator + 
              LocalDate.now() + "_" + time + "_" + tr
              .getMethod().getTestClass() + "_" + tr.getMethod().getMethodName() + ".png";
            File dest = new File(f);
            FileUtils.copyFile(scrFile, dest);
            StringBuilder href = new StringBuilder();
            Reporter.log(new StringBuilder().append("<div><a HREF='")
              .append(dest
              .getAbsolutePath()).append("'><img src='")
              .append(dest
              .getAbsolutePath()).append("' alt='Screen Shot' style='width:250px;height:200px'>Link to Screeshot</a></div>").toString());

            Reporter.setCurrentTestResult(tr);
            Reporter.setCurrentTestResult(null);
          }
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }

  protected String parseUnixTimeToTimeOfDay(long unixSeconds) {
    Date date = new Date(unixSeconds);
    sdftime.setTimeZone(TimeZone.getTimeZone(timeZone));
    return sdftime.format(date);
  }

  public void onTestSkipped(ITestResult tr)
  {
    synchronized (this) {
      Reporter.log("-Skipped-", true);
      EnvirnomentHandler.getInstance(); boolean islocal = EnvirnomentHandler.getEnvirnoment().isLocal();
      try
      {
        String group = Arrays.toString(
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .groups()).replace("[", "");

        group = group.replace("]", "");

        WriteExcel.createContent(sheet, 1, i, group);

        WriteExcel.createContent(sheet, 2, i, 
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .testName());

        WriteExcel.createContent(sheet, 3, i, 
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .description());

        WriteExcel.createContent(sheet, 4, i, "Skip");
        WriteExcel.createContent(sheet, 5, i, getDate());

        i += 1;
      }
      catch (WriteException e1) {
        e1.printStackTrace();
      }
      if (islocal) {
        WebDriver driver = (WebDriver)tr.getTestContext().getAttribute("driver");
        System.setProperty("org.uncommons.reportng.escape-output", "false");
        File file = new File("");
        Calendar lCDateTime = Calendar.getInstance();
        String time = parseUnixTimeToTimeOfDay(lCDateTime.getTimeInMillis()).replace(":", "").replace(" ", "");
        Reporter.log("IN TEST SKIPPED METHOD" + time, true);
        try {
          System.out.println(file.getCanonicalPath());
          File scrFile = (File)((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

          String f = file.getCanonicalPath() + File.separator + "target" + File.separator + "surefire-reports" + File.separator + 
            LocalDate.now() + "_" + time + "_" + tr.getMethod().getTestClass() + "_" + tr
            .getMethod().getMethodName() + ".png";
          File dest = new File(f);
          FileUtils.copyFile(scrFile, dest);
          StringBuilder href = new StringBuilder();
          Reporter.log(new StringBuilder().append("<div><a HREF='")
            .append(dest
            .getAbsolutePath()).append("'><img src='").append(dest.getAbsolutePath()).append("' alt='Screen Shot' style='width:250px;height:200px'></a></div>").toString());

          Reporter.setCurrentTestResult(tr);
          Reporter.setCurrentTestResult(null);
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }

  public void onTestSuccess(ITestResult tr)
  {
    synchronized (this) {
      Reporter.log("-Passed-", true);
      try
      {
        String group = Arrays.toString(
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .groups()).replace("[", "");

        group = group.replace("]", "");
        WriteExcel.createContent(sheet, 1, i, group);

        WriteExcel.createContent(sheet, 2, i, 
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .testName());

        WriteExcel.createContent(sheet, 3, i, 
          ((Test)tr
          .getMethod().getConstructorOrMethod().getMethod()
          .getAnnotation(Test.class))
          .description());

        WriteExcel.createContent(sheet, 4, i, "Pass");
        WriteExcel.createContent(sheet, 5, i, getDate());
        i += 1;
      } catch (WriteException e1) {
        e1.printStackTrace();
      }
    }
  }

  private String getDate() { Date dNow = new Date();
    SimpleDateFormat ft = new SimpleDateFormat("MM.dd.yyyy hh:mm:ss a zzz");
    return ft.format(dNow);
  }
}