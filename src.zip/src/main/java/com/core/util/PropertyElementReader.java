package com.core.util;

import java.util.Properties;
import org.testng.Assert;
import org.testng.Reporter;

public class PropertyElementReader
{
  private static PropertyElementReader _instance;
  private static String mylocale = "en_US";

  private static Properties baseElements = new Properties();

  private static Properties overridingElements = new Properties();

  public static PropertyElementReader getInstance(String locale) {
    if (_instance == null) {
      mylocale = locale;
      _instance = new PropertyElementReader();
    }
    return _instance;
  }

  private PropertyElementReader() {
    loadPropertyElements();
  }

  public String getPropertyElement(String key) {
    if ((overridingElements != null) && 
      (overridingElements
      .containsKey(key)))
    {
      return overridingElements.getProperty(key);
    }

    if ((baseElements != null) && 
      (baseElements
      .containsKey(key)))
    {
      return baseElements.getProperty(key);
    }

    Assert.fail("Could not find property element for key '" + key + "'");
    return null;
  }

  private void loadPropertyElements() {
    try {
      if (mylocale.equals("en_US_MOBILE")) {
        baseElements.load(getClass().getResourceAsStream("/elements/baseElements.properties"));
      }
      else if (mylocale.equals("en_CN_WEB"))
        baseElements.load(getClass().getResourceAsStream("/elements/baseElements_sCN.properties"));
    }
    catch (Exception e)
    {
      Reporter.log("Could not load base element file.", 3);
    }
  }
}