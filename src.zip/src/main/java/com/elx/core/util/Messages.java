package com.elx.core.util;

import java.util.Locale;
import java.util.ResourceBundle;

public class Messages
{
  private final ResourceBundle appBundle;

  public Messages(String baseName, Locale locale)
  {
    this.appBundle = ResourceBundle.getBundle(baseName, locale);
  }

  public static Messages getInstance(String baseName, Locale locale)
  {
    return new Messages(baseName, locale);
  }

  public String getMessage(String key)
  {
    return this.appBundle.getString(key).trim();
  }

  public static String getKey(String page, String msgKey)
  {
    if ((null == page) || (null == msgKey)) {
      return null;
    }

    return page + "." + msgKey;
  }
}