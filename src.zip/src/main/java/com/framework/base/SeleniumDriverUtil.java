package com.framework.base;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.Reporter;
import com.dto.handler.EnvirnomentHandler;
import com.dto.Envirnoment;

public class SeleniumDriverUtil
{
  private static String URL;
  private static Envirnoment env = EnvirnomentHandler.getEnvirnoment();
  private WebDriver driver;

  public WebDriver getDriver()
  {
    DesiredCapabilities desiredCapabilities = null;
    String browser = null;
    browser = env.getBrowser();
    Reporter.log("********************************************************", true);
    Reporter.log("      Executing on " + browser + " browser                  ", true);
    Reporter.log("********************************************************", true);
    if (System.getProperty("os.name").toLowerCase().substring(0, 3).equals("win")) {
      Reporter.log("*********************************************************************", true);
      Reporter.log("      Executing on " + System.getProperty("os.name") + " Environment.    ", true);
      Reporter.log("*********************************************************************", true);
      if (browser.equalsIgnoreCase("firefox")) {
        desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setBrowserName("QuickView");
        desiredCapabilities.setPlatform(Platform.WINDOWS);
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("BROWSER.cache.disk.enable", false);
        profile.setPreference("BROWSER.cache.memory.enable", false);
        profile.setPreference("BROWSER.cache.offline.enable", false);
        profile.setPreference("network.http.use-cache", false);
        if (this.driver == null) {
          if (!env.isLocal())
            try {
              this.driver = new RemoteWebDriver(new URL(env.getGridURL()), desiredCapabilities);
            } catch (MalformedURLException e) {
              e.printStackTrace();
            }
          else
            this.driver = new FirefoxDriver();
        }
        else {
          return this.driver;
        }
      }
      else if (browser.equalsIgnoreCase("ie")) {
        System.out.println("BROWSER IS::::" + browser);
        if (this.driver == null)
        {
          String FILEPATH = System.getProperty("user.dir") + "/" + "src/main/resources/exe/windowsdriver/IEDriverServer.exe";
          File file = new File(FILEPATH);
          System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
          desiredCapabilities = DesiredCapabilities.internetExplorer();
          desiredCapabilities.setCapability("ignoreProtectedModeSettings", true);

          desiredCapabilities.setJavascriptEnabled(true);
          desiredCapabilities.setCapability("ignoreZoomSetting", true);
          desiredCapabilities.setCapability("nativeEvents", false);
          desiredCapabilities.setCapability("requireWindowFocus", true);
          desiredCapabilities.setCapability("enablePersistentHover", false);
          desiredCapabilities.setCapability("EnableNativeEvents", false);
          if (!env.isLocal())
            try {
              this.driver = new RemoteWebDriver(new URL(env.getGridURL()), desiredCapabilities);
            } catch (MalformedURLException e) {
              e.printStackTrace();
            }
          else
            this.driver = new InternetExplorerDriver(desiredCapabilities);
        }
        else {
          return this.driver;
        }
      }
      else if (browser.equalsIgnoreCase("chrome")) {
        if (this.driver == null)
        {
          String FILEPATH = System.getProperty("user.dir") + "/" + "src/main/resources/exe/windowsdriver/chromedriver.exe";
          File file = new File(FILEPATH);
          System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
          if (!env.isLocal())
            try {
              this.driver = new RemoteWebDriver(new URL(env.getGridURL()), 
                DesiredCapabilities.chrome());
            } catch (MalformedURLException e) {
              e.printStackTrace();
            }
          else
            this.driver = new ChromeDriver();
        }
        else {
          return this.driver;
        }
      } else if (browser.equalsIgnoreCase("qnx")) {
        ChromeOptions options = new ChromeOptions();

        DesiredCapabilities dc = DesiredCapabilities.chrome();
        dc.setCapability("browserStartWindow", "*");
        try {
          this.driver = new RemoteWebDriver(new URL(env.getGridURL()), dc);
        } catch (MalformedURLException e) {
          e.printStackTrace();
        }
      } else if ((browser.equalsIgnoreCase("headless")) && 
        (this.driver == null)) {
        desiredCapabilities = new DesiredCapabilities();
      }

    }
    else if (System.getProperty("os.name").toLowerCase().substring(0, 3).equals("mac")) {
      Reporter.log("*********************************************************************", true);
      Reporter.log("      Executing on " + System.getProperty("os.name") + " Environment.    ", true);
      Reporter.log("*********************************************************************", true);
      if (browser.equalsIgnoreCase("chrome")) {
        if (this.driver == null)
        {
          String FILEPATH = System.getProperty("user.dir") + "/" + "src/main/resources/exe/macdriver/chromedriver";
          File file = new File(FILEPATH);
          System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
          if (!env.isLocal())
            try {
              this.driver = new RemoteWebDriver(new URL(env.getGridURL()), 
                DesiredCapabilities.chrome());
            } catch (MalformedURLException e) {
              e.printStackTrace();
            }
          else {
            this.driver = new ChromeDriver();
          }
          Reporter.log("Executing MAC Chrome driver....", true);
        } else {
          return this.driver;
        }
      } else if (browser.equalsIgnoreCase("firefox")) {
        if (this.driver == null) {
          if (!env.isLocal())
            try {
              this.driver = new RemoteWebDriver(new URL(env.getGridURL()), 
                DesiredCapabilities.firefox());
            } catch (MalformedURLException e) {
              e.printStackTrace();
            }
          else
            this.driver = new FirefoxDriver();
        }
      }
      else if (browser.equalsIgnoreCase("headless")) {
        if (this.driver != null)
        {
          return this.driver;
        }
      } else if (browser.equalsIgnoreCase("safari")) {
        if (this.driver == null)
          this.driver = new SafariDriver();
        else {
          return this.driver;
        }
      }
    }
    return this.driver;
  }

  public static String getLoginURL() {
    Reporter.log("URL is:" + URL, true);
    return URL;
  }

  static
  {
    EnvirnomentHandler.getInstance();
  }
}