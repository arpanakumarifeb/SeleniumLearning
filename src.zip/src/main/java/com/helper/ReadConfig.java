package com.helper;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

import com.dto.Envirnoment;
import com.dto.handler.EnvirnomentHandler;


public class ReadConfig {
	private static Envirnoment env = EnvirnomentHandler.getInstance().getEnvirnoment();
	public static Logger APP_LOGS = null;
	public FileInputStream fisConfig = null;

	public static Properties CONFIG = null;
	public ReadConfig() {
		APP_LOGS = Logger.getLogger(ReadConfig.class.getName());
		try {
			if (CONFIG == null) {
				APP_LOGS.info("Loading config properties");
				if(env.getEnv().equals("masterbox")){
				fisConfig = new FileInputStream(System.getProperty("user.dir")
						+ IConstants.MASTER_ENV_PROPS);
				}else{
					fisConfig = new FileInputStream(System.getProperty("user.dir")
							+ IConstants.QA_ENV_PROPS);
					
				}
				CONFIG = new Properties();
				CONFIG.load(fisConfig);
			}
		} catch (FileNotFoundException fnf) {
			APP_LOGS.info("The config properties file is not found");
			fnf.printStackTrace();
		} catch (IOException ioe) {
			APP_LOGS.info("Unable to loading config properties");
			ioe.printStackTrace();
		}
	}
public Properties getConfig(){
	return CONFIG;
}
}
