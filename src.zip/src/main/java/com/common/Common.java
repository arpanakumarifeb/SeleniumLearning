package com.common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
//import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.MoveTargetOutOfBoundsException;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.common.Common;
//import com.automation.framework.util.HttpUtils;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.helper.IConstants;
import com.web.pages.WebTestCase;

import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;

/**
 * This class contains all the common methods for common selenium events which
 * can be reused through out the project.
 * 
 */

@SuppressWarnings({ "unused" })
public class Common extends WebTestCase {

	private static boolean initialized = true;
	private static WebDriver driver;// = selenium.getDriver();
	private Logger logger = Logger.getLogger(Common.class.getName());
	private static final long SLEEP_SWITCH = 30000l;
	private static final long SLEEP_THREAD_SLEEP = 250;
	// private static com.automation.framework.util.HttpUtils httpUtils;

	Robot robot = null;
	public Common(WebDriver driver2) {
		driver = driver2;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method is used for switch windows
	 */
	public void getWindowHandle(String title) {
		Set<String> handles = driver.getWindowHandles();
		if (handles.size() >= 1) {
			System.out.println("Number of browsers opened are" + handles.size());
			for (String handle : handles) {
				driver.switchTo().window(handle);
				if (driver.getTitle().contains(title)) {
					driver.getWindowHandle();
					break;
				}

			}
		}
	}

	public String geturl(String Env) {
		return Env;
	}

	/**
	 * method to handle scrolling to a particular webelement
	 * 
	 * @param e
	 *            Webelement e
	 * 
	 */
	public void scrollIntoViewPage(WebElement e) {

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", e);
	}

	/**
	 * method to modify the css value of Top attribute
	 * 
	 * @param e
	 *            , px Webelement e Pixel position px
	 * 
	 */
	public void top(WebElement e, int px) {
		((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('style', 'top: 70px;');", e);
	}

	/**
	 * method is used as handle Explicit wait
	 * 
	 */
	public WebElement explicitWait(final By by) {
		final Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(60, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS).ignoring(NoSuchElementException.class)
				.ignoring(TimeoutException.class).ignoring(ElementNotVisibleException.class).ignoring(Exception.class);
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				return wait.until(ExpectedConditions.presenceOfElementLocated(by));
			}
		});
		return element;
	}

	/**
	 * @param mouseClick
	 *            method is to perform click operation using mouse interactions
	 *            This method was written to handle chrome related issues on
	 *            clicking on an element
	 */
	public void mouseClick(WebElement e) {
		Actions action = new Actions(driver);
		action.moveToElement(e).click().perform();
	}

	/**
	 * @param mouseDblClick
	 *            method is to perform click operation using mouse interactions
	 *            This method was written to handle chrome related issues on
	 *            clicking on an element
	 */
	public void mouseDblClick(WebElement e) {
		Actions action = new Actions(driver);
		action.moveToElement(e).doubleClick().perform();
	}

	/**
	 * @param tabClick
	 *            method is to perform click operation using mouse interactions
	 *            This method was written to handle chrome related issues on
	 *            clicking on an element
	 */
	public void tabClick(WebElement e) {
		Actions action = new Actions(driver);
		action.moveToElement(e).sendKeys(Keys.TAB).perform();
	}


	/**
	 * @param slidermovement
	 *            method is to perform drag and drop the slider from one
	 *            position to other position *
	 */
	public void slidermovement(WebElement e, int pixelsLeft, int pixelright) {
		Actions dragger = new Actions(driver);
		dragger.moveToElement(e).clickAndHold().moveByOffset(pixelsLeft, pixelright).release().perform();
	}

	/**
	 * @param moveto
	 *            (WebElement e) method is to perform mouse over on particular
	 *            webelement *
	 */
	public void moveto(WebElement e) {
		try {
			Actions actn = new Actions(driver);
			actn.moveToElement(e).perform();
		} catch (MoveTargetOutOfBoundsException mtobe) {
			Reporter.log(
					"-please wait some more time and perform move to operation to avoid this exception-because when you are trying to move the element is not visible-",
					true);
			mtobe.printStackTrace();
		}

	}

	/**
	 * @param scrolling
	 *            () scrolling howard stern NPL page to see all the available
	 *            episodes *
	 */
	public void scrolling() {

		List<WebElement> image = driver.findElements(By.xpath(
				"/html/body/div[3]/div/div/div[2]/div[1]/div[1]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div[2]/div//span[2]"));

		for (WebElement clickimg : image) {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", clickimg);
			Reporter.log(clickimg.getText(), true);
		}
	}

	/**
	 * @param contextclick
	 *            (WebElement e) to perform right click on a particular
	 *            webelement
	 * @param e
	 */
	public void contextclick(WebElement e) {
		Actions a = new Actions(driver);
		a.contextClick(e).perform();
	}

	/**
	 * @param click
	 *            (WebElement e) to perform click on a particular
	 *            webelement
	 * @param e
	 */
	public void click(WebElement e) {
		Actions a = new Actions(driver);
		a.click(e) .perform();
	}


	/**
	 * @param dragAndDrop
	 *            (WebElement drag, WebElement drop) to perform drag and drop of
	 *            a particular element on to the target element
	 */
	public void dragAndDrop(WebElement drag, WebElement drop) {
		Actions a = new Actions(driver);
		a.dragAndDrop(drag, drop).perform();
	}

	/**
	 * @param dragAndDrop
	 *            (WebElement drag, WebElement drop) to perform drag and drop of
	 *            a particular element on to the target element
	 */
	public void impicitWait(int seconds) {
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			Thread.sleep(1000 * seconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void clickHoldDragDrop(WebElement e, WebElement e1) {
		Actions action = new Actions(driver);
		action.moveToElement(e).build().perform();
		// action.clickAndHold(e).build().perform();
		action.dragAndDrop(e, e1).build().perform();
		// action.release(e).perform();

	}

	/**
	 * verifyText(String s, String s1) Method to validate the text comparision
	 */

	public void verifyText(String s, String s1) {
		boolean flag = false;
		if (s1.contains(s)) {
			flag = true;
			Reporter.log("" + s1 + " and " + s + " are same", true);
			Assert.assertTrue(flag);
		} else {
			Reporter.log("" + s1 + " and " + s + " are not same", true);
			Assert.assertTrue(flag);
		}

	}

	/**
	 * containsAll() returns true if the collection contains all the elements in
	 * the parameter collection, and false if not.
	 * 
	 * @param <T>
	 * @param a
	 * @param b
	 */
	public <T> void verifyListData(List<T> a, List<T> b) {
		boolean flag = false;
		String mismatchVins = null;
		if (a.containsAll(b)) {
			flag = a.removeAll(b);
			if (flag) {
				mismatchVins = getMismatchVins(a);
			}
		} else {
			flag = b.removeAll(a);
			if (flag) {
				mismatchVins = getMismatchVins(b);
			}
		}
		if (mismatchVins != null) {
			Reporter.log("not equals data:" + mismatchVins, true);
			Assert.assertTrue(false);
		} else {
			Reporter.log("equals data:", true);
			Assert.assertTrue(true);
		}
	}

	/**
	 * getMismatchVins
	 * 
	 * @param b
	 * @return
	 */
	public <T> String getMismatchVins(List<T> b) {
		StringBuilder mismatchVins = new StringBuilder();
		int i = 0;
		for (T mismatch : b) {
			i++;
			if (i < b.size() && i != b.size()) {
				mismatchVins.append(mismatch).append(",");
			} else {
				mismatchVins.append(mismatch);
			}
			if (i == b.size()) {
				break;
			}
		}
		String mismatch1;
		if (mismatchVins.length() > b.size()) {
			mismatch1 = mismatchVins.substring(0, 99);
		} else {
			mismatch1 = mismatchVins.toString();
		}
		return mismatch1;
	}

	/**
	 * mainWindowHandle() To handle multiple windows
	 */

	public String mainWindowHandle() {
		String mainWindow = driver.getWindowHandle();
		System.out.println(mainWindow + ":main window");
		return mainWindow;
	}

	/**
	 * mainWindowTitle() To handle multiple windows
	 */
	public String mainWindowTitle() {
		String mainWindowTitle = driver.getTitle();
		System.out.println(mainWindowTitle + ":main window title");
		return mainWindowTitle;
	}

	/**
	 * childWindowHandles(String mainWindowHandle) To handle multiple windows
	 */
	public void childWindowHandles(String mainWindowHandle) {
		// maximizeWindow();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> ite = s.iterator();
		while (ite.hasNext()) {
			String childWindow = ite.next().toString();
			if (!childWindow.contains(mainWindowHandle)) {
				driver.switchTo().window(childWindow);
				String childWindow_title = driver.getTitle();
				System.out.println(childWindow_title + ":after switching child window");
				implicitWait(10);
			}
		}
	}

	/**
	 * switchToMainWidnow(String mainWindowTitle) To handle multiple windows
	 */
	public boolean switchToMainWidnow(String mainWindowTitle) {
		boolean flag = false;
		int dSize = driver.getWindowHandles().size();
		System.out.println("windows size before closing child window:" + dSize);
		if (dSize > 1) {
			driver.close();
		}
		int dSize1 = driver.getWindowHandles().size();
		System.out.println("windows size after closing child window:" + dSize1);
		Set<String> availableWindows = driver.getWindowHandles();
		if (!availableWindows.isEmpty()) {
			for (String windowId : availableWindows) {
				if (driver.switchTo().window(windowId).getTitle().equals(mainWindowTitle)) {
					flag = true;
				}
			}
		}
		return flag;
	}

	/**
	 * switchToDefault() To switch back to default page after perfomring actions
	 * in frame tag
	 */
	public void switchToDefault() {
		driver.switchTo().defaultContent(); // you are now outside both frames
	}

	/**
	 * verifyPDFText() To validate the pdf text on Siriusxm Login page
	 */
	// public String verifyPDFText() {
	// String output = null;
	// try {
	// URL url = new URL(driver.getCurrentUrl());
	// URLConnection urlConn = url.openConnection();
	// Reporter.log("current url:" + driver.getCurrentUrl(), true);
	// FileInputStream fileToParse = new
	// FileInputStream(urlConn.getURL().getFile());
	// PDFParser parser = new PDFParser(fileToParse);
	// parser.parse();
	// output = new PDFTextStripper().getText(parser.getPDDocument());
	// Reporter.log("PDF text is:" + output, true);
	// parser.getPDDocument().close();
	//
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	//
	// return output;
	// }

	/**
	 * implicitWait(int seconds) wait command for implicitly waiting for the
	 * page to load
	 */
	public void implicitWait(int seconds) {
		try {
			driver.manage().timeouts().implicitlyWait(seconds * 10, TimeUnit.SECONDS);
		} catch (TimeoutException toe) {
			toe.printStackTrace();
		}
	}

	/**
	 * pageLoad(int seconds) wait for page to load before timout exception is
	 * thrown
	 */
	public void pageLoad(int seconds) {
		driver.manage().timeouts().pageLoadTimeout(seconds * 10, TimeUnit.SECONDS);
	}

	/**
	 * waitForDriver(WebElement e, int sleeptTime, int rounds) wait for
	 * particular element and loop for every given number of seconds
	 */
	public boolean waitForDriver(WebElement e, int sleeptTime, int rounds) {
		boolean flag = false;

		L1: for (int i = 0; i < rounds; i++) {
			Reporter.log("-waiting for element " + (i + 1) + " time-", true);
			driver.manage().timeouts().implicitlyWait(sleeptTime * 10, TimeUnit.SECONDS);
			try {
				if (isElementPresent(e)) {
					flag = true;
					Assert.assertTrue(flag);
					break;
				} else {
					throw new Exception("element not displayed");
				}
			} catch (Exception ee) {
				Reporter.log("-wait for element-" + e, true);
				continue L1;
			}
		}
		return flag;
	}

	/**
	 * waitForElement(final WebElement e, int timeOut,WebDriver driver) Selenium
	 * explicit wait command to wait for particular webelement
	 */
	public boolean waitForElement(final WebElement e, int timeOut, WebDriver driver) {
		try {
			new WebDriverWait(driver, timeOut) {
			}.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driverObject) {
					return isElementPresent(e);

				}
			});
		} catch (NoSuchElementException noSuchElementException) {
			noSuchElementException.printStackTrace();
			System.out.println("NoSuchElementException exception for : " + noSuchElementException.toString());
			Reporter.log("NoSuchElementException exception for " + noSuchElementException.toString());
			return false;
		} catch (TimeoutException timeoutException) {
			timeoutException.printStackTrace();
			System.out.println("TimeoutException exception for : " + timeoutException.toString());
			Reporter.log("TimeoutException exception for " + timeoutException.toString());
			return false;
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Some other exception for : " + exception.toString());
			Reporter.log("Some other exception for " + exception.toString());
			return false;
		} finally {
			driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.MILLISECONDS);
		}

		System.out.println(e.toString() + " is enabled: ");
		Reporter.log(e.toString() + " is enabled: ");
		return true;
	}

	/**
	 * This method id used to clicking on object
	 * 
	 * @param e
	 * @param objectname
	 * @return
	 */
	public boolean clickOnObject(WebElement e, String objectname) {
		String object= e.getText();
		try {
			//String s;
			if (e == null) {
				System.out.println(objectname + "does not exist on webpage");
				Reporter.log(objectname + "does not exist on webpage");
				return false;
			}

		} catch (Exception exception) {

		}
		// handleUnexpectedDialog(3);
		boolean isClickDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (isElementPresent(e)) {
				if (e != null) {
					e.click();
					System.out.println("clicked on object" + object);

					/*String javaScript = "var evObj = document.createEvent('MouseEvents');"
							+ "evObj.initMouseEvent(\"click\",true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
							+ "arguments[0].dispatchEvent(evObj);";

					((JavascriptExecutor) driver).executeScript(javaScript, e);
					System.out.println("clicked the " + objectname);
					isClickDone = true;*/
				}
			}
		} catch (Exception exception3) {
			e.click();
			System.out.println("clicked on " + e.getText());
			Reporter.log("Some Exception happened ");
		}
		/*if (isClickDone == false) {
			return false;
		}*/
		Reporter.log("Clicked the " + objectname);
		return true;
	}

	public boolean selectByVisibleText(WebElement e, String objectname, String objValue) {
		try {

			if (e == null) {
				Reporter.log(objectname + "does not exist on webpage", true);
				Reporter.log(objectname + "does not exist on webpage");
				return false;
			}

		} catch (Exception exception) {
		}
		// handleUnexpectedDialog(3);
		boolean isSelectDone = false;
		try {
			// if (isElementPresent(e)) {
			if (e != null) {
				e = waitForElementToBeDisplayed(e, 40);
				Select select = new Select(e);
				select.selectByVisibleText(objValue);
				Reporter.log("clicked the object1");
				isSelectDone = true;
			}
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ");
		}
		if (isSelectDone == false) {
			return false;
		}
		Reporter.log(objectname + " Value is Selected to :-" + objValue);
		return true;
	}

	public boolean selectByIndex(WebElement e, String objectname, int objValue) {
		try {

			if (e == null) {
				System.out.println(objectname + "does not exist on webpage");
				Reporter.log(objectname + "does not exist on webpage");
				return false;
			}

		} catch (Exception exception) {

		}
		// handleUnexpectedDialog(3);

		boolean isSelectDone = false;
		try {

			// if (isElementPresent(e) == true) {

			e = waitForElementToBeDisplayed(e, 40);
			if (e != null) {
				Select select = new Select(e);
				select.selectByIndex(objValue);
			}
			Reporter.log("clicked the object1", true);
			isSelectDone = true;
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ", true);
		}
		if (isSelectDone == false) {
			return false;
		}
		Reporter.log(objectname + " Value is Selected to :-" + objValue);
		return true;
	}

	public List<WebElement> getallvaluesfromSelectbox(WebElement e, String objectname) {

		Select dropdown  = new Select(e);
		List<WebElement> dd = dropdown.getOptions();
		System.out.println(dd.size());
		for (int j = 0; j < dd.size(); j++) {
			System.out.println(dd.get(j).getText());

		}
		return dd;
	}

	/**
	 * This method is used to set the object value
	 * 
	 * @param e
	 * @param objectname
	 * @param objValue
	 * @return
	 */
	public boolean setObjectValue(WebElement e, String objectname, String objValue) {
		boolean isSetDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (e != null) {
				e.clear();
				e.sendKeys(objValue);

				System.out.println("Enter in text box:::" + objValue);
				isSetDone = true;
			}
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ");
		}
		if (isSetDone == false) {
			return false;
		}
		Reporter.log(objectname + " Value is set to :-" + objValue);
		return true;
	}

	/**
	 * This method is used to verify Object contains the specific value/text.
	 * 
	 * @param e
	 * @param objectname
	 * @param objValue
	 * @return
	 */
	public boolean verifyObjectContainsValue(WebElement e, String objectname, String objValue) {
		boolean isSetDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (e != null) {
				if (e.getText().contains(objValue)) {
					Reporter.log(objectname + " Contains Value as :-" + objValue);
					isSetDone = true;
				}
			}
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ");
		}
		if (isSetDone == false) {
			Reporter.log(objectname + " not Contains Value as :-" + objValue);
			return false;
		}
		Reporter.log(objectname + " Contains Value as :-" + objValue);
		return true;
	}

	/**
	 * This method is used to verify whether the given value is equal.
	 * 
	 * @param e
	 * @param objectname
	 * @param objValue
	 * @return
	 */
	public boolean verifyObjectEqualValue(WebElement e, String objectname, String objValue) {
		boolean isSetDone = false;
		try {
			e = waitForElementToBeDisplayed(e, 40);
			if (e != null) {
				if (e.getText().equalsIgnoreCase(objValue)) {
					Reporter.log(objectname + " equal Value to :-" + objValue);
					isSetDone = true;
				}
			}
		} catch (Exception exception3) {
			Reporter.log("Some Exception happened ");
		}
		if (isSetDone == false) {
			Reporter.log(objectname + " not equal Value to :-" + objValue);
			return false;
		}
		return true;
	}

	/**
	 * This method is used to handle the unexpected dialog.
	 * 
	 * @param timeout
	 */
	private void handleUnexpectedDialog(int timeout) {
		WebDriverWait Wait = new WebDriverWait(driver, timeout);
		WebElement element = null;
		try {
			element = Wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
					"//*[@class='fsrCloseBtn' or @id='tcChat_btnCloseChat_img' or @id='tcXF18000443_xf-10Ãƒâ€šÃ‚Â·1']")));
			if (element != null) {
				if (element.isEnabled()) {
					element.click();
					Reporter.log("Feedback  or chat dialog poped up. Clicked to get rid off");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * isElementPresent(WebElement e) Method to validate a particular webelement
	 * is available on webpage or not
	 */
	public boolean isElementPresent(WebElement e) {
		try {
			if (e == null) {
				Reporter.log("Control does not exist on page", true);
				return false;
			}
			//handleUnexpectedDialog(1);

			if (e.isEnabled() == false) {
				Reporter.log("Element not displayed", true);
				return false;
			}
		} catch (NoSuchElementException nsee) {
			Reporter.log(e.toString() + " is not available");
			return false;
		}
		Reporter.log("Information ::::Element "+e.getText()+" is available for further actions", true);
		return true;
	}

	/**
	 * elementToBeClickable(final By by, int timeInSeconds) Method to perform
	 * click operation on any element once it is visible to perform the action
	 */
	public WebElement elementToBeClickable(final By by, int timeInSeconds) {
		return new FluentWait<WebDriver>(driver)
				// Wait for the condition
				.withTimeout(timeInSeconds * 10, TimeUnit.SECONDS)
				// which to check for the condition with interval of 5 seconds.
				.pollingEvery(2, TimeUnit.SECONDS)
				// Which will ignore the NoSuchElementException
				.ignoring(NoSuchElementException.class).ignoring(ElementNotVisibleException.class)
				.ignoring(WebDriverException.class).until(new ExpectedCondition<WebElement>() {
					public ExpectedCondition<WebElement> FluentWaitMethodNameObj = ExpectedConditions
							.elementToBeClickable(by);

					@Override
					public WebElement apply(WebDriver driver) {
						WebElement element = FluentWaitMethodNameObj.apply(driver);
						try {
							if (element != null && element.isDisplayed()) {
								return element;
							} else {
								return null;
							}
						} catch (StaleElementReferenceException e) {
							Reporter.log("--Stale Element Exception--", true);
							e.printStackTrace();
							return null;
						} catch (TimeoutException toe) {
							Reporter.log("--Time Out Exception--", true);
							toe.printStackTrace();
							return null;
						}
					}
				});
	}

	/**
	 * waitForElementPresent(final By by, int timeOutInSeconds) Method to check
	 * element is visible or not .If not available wait for the amount of the
	 * time given
	 */
	public void waitForElementPresent(final By by, int timeOutInSeconds) {
		WebElement element;
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			element = wait.until(ExpectedConditions.presenceOfElementLocated(by));
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * findDuplicates(List<String> input Method to check duplicates in a list
	 * 
	 */
	public static HashSet<String> findDuplicates(List<String> input) {
		List<String> copy = new ArrayList<String>(input);
		for (String value : new HashSet<String>(input)) {
			copy.remove(value);
		}
		return new HashSet<String>(copy);
	}

	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}



	public boolean isElementVisible(By by) {
		try {
			driver.findElement(by).isEnabled();
			driver.findElement(by).isDisplayed();
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	/**
	 * This method id used to wait for page load with dynamic web control.
	 * 
	 * @param ee
	 * @param validationstring
	 * @return boolean value
	 */
	public boolean waitForPageLoadwithDynamicControl(WebElement ee, String validationstring) {
		long startTime = System.currentTimeMillis();
		long endTime = startTime + 60 * 1000;
		boolean flag = false;
		boolean isPageReadyForValidation = true;
		if (waitForPageIsLoadingProgress(driver, startTime, endTime) == false) {
			Reporter.log("spinner is appearing");
			isPageReadyForValidation = false;
		}
		if (waitForPageLoad(driver) == false) {
			Reporter.log("not loaded in given time");
			isPageReadyForValidation = false;
		}
		handleUnexpectedDialog(3);

		if (isPageReadyForValidation == true) {
			if (isElementPresent(ee)) {

				if (ee.getText().trim().contains(validationstring))
					flag = true;
				else
					flag = false;
			}
		}
		return flag;
	}

	/**
	 * This method id used to wait for web page loading status(progress)
	 * 
	 * @param driver
	 * @param startTime
	 * @param endTime
	 * @return boolean
	 */
	public boolean waitForPageIsLoadingProgress(WebDriver driver, long startTime, long endTime) {
		boolean flag = true;
		String spinnerAppearing = "<div class=\"spinner\" ng-show=\"isLoading\">";
		handleUnexpectedDialog(2);
		while ((driver.getPageSource().contains(spinnerAppearing))) {
			if (System.currentTimeMillis() > endTime) {
				Reporter.log("Wait..... Spinner is appearing");
				flag = false;
				System.out.println("Spinner is appearing");
			}
			try {
				Thread.sleep(30);
			} catch (Exception e) {
			}
		}
		return flag;
	}

	/**
	 * This method is used to verify wait for page load.
	 * 
	 * @param driver
	 * @return boolean value
	 */
	public boolean waitForPageLoad(WebDriver driver) {

		long startTime = System.currentTimeMillis();
		long waitTime = 120000;
		String pageLoadStatus = null;
		try {
			do {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				pageLoadStatus = (String) js.executeScript("return document.readyState");
				System.out.print((System.currentTimeMillis() - startTime));

				if ((System.currentTimeMillis() - startTime) > waitTime) {

					Reporter.log("timeout completed " + waitTime + "ms");

					return false;
				}
				System.out.println("waiting for page load");
				Thread.sleep(100);
			} while (!pageLoadStatus.equals("complete"));
			System.out.println("Page Loaded correctly");

		} catch (Exception e) {
			System.out.println("some Exeption happened during page load:::::" + e.toString());
		}
		return true;
	}

	/**
	 * This method is able to do muse hover on web element.
	 * 
	 * @param e
	 *            - WebElement
	 */
	public void MouseHoverFunction(WebElement e) {
		try {
			String javaScript = "var evObj = document.createEvent('MouseEvents');"
					+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
					+ "arguments[0].dispatchEvent(evObj);";

			((JavascriptExecutor) driver).executeScript(javaScript, e);

			System.out.println("MouseHoverFunction");
		} catch (Exception ee) {
		}
	}

	/**
	 * This method is used to wait for web element to be displayed in given time
	 * 
	 * @param element
	 * @param timeInSeconds
	 * @return WebElement
	 */
	public WebElement waitForElementToBeDisplayed(WebElement element, int timeInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeInSeconds);
			element = wait.until(ExpectedConditions.elementToBeClickable(element));
			if (element != null && element.isDisplayed()) {

				return element;
			} else {
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("FAIL" + "--No Such Element Exception--", true);
			e.printStackTrace();
			return null;

		} catch (StaleElementReferenceException e) {
			Reporter.log("FAIL" + "--Stale Element Exception--", true);
			e.printStackTrace();
			return null;
		} catch (TimeoutException toe) {
			Reporter.log("FAIL" + "--Time Out Exception--", true);
			toe.printStackTrace();
			return null;
		}
	}

	/**
	 * This method is used to wait for web element to be visible in given time
	 * 
	 * @param element
	 * @param timeInSeconds
	 * @return WebElement
	 */
	public WebElement waitForElementLoaded(WebElement element, int timeInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeInSeconds);
			element = wait.until(ExpectedConditions.visibilityOf(element));
			if (element != null && element.isDisplayed()) {

				return element;
			} else {
				return null;
			}
		} catch (NoSuchElementException e) {
			Reporter.log("FAIL" + "--No Such Element Exception--", true);
			e.printStackTrace();
			return null;

		} catch (StaleElementReferenceException e) {
			Reporter.log("FAIL" + "--Stale Element Exception--", true);
			e.printStackTrace();
			return null;
		} catch (TimeoutException toe) {
			Reporter.log("FAIL" + "--Time Out Exception--", true);
			toe.printStackTrace();
			return null;
		}
	}

	/**
	 * wait the download page (on Javascript readyState)
	 */
	public void waitForPageToLoad() {
		logger.info("Waiting for page to load");
		WebDriverWait wait = new WebDriverWait(driver, 300);

		try {
			wait.until((ExpectedCondition<Boolean>) new ExpectedCondition<Boolean>() {
				public Boolean apply(final WebDriver d) {
					if (!(d instanceof JavascriptExecutor)) {
						return true;
					}
					Object result = ((JavascriptExecutor) d)
							.executeScript("return document['readyState'] ? 'complete' == document.readyState : true");
					if (result != null && result instanceof Boolean && (Boolean) result) {
						return true;
					}
					return false;
				}
			});
		} catch (Exception e) {
			logger.info("Page is NOT loaded and got TimeOut");
		}
	}

	/**
	 * waiting, while number of open windows will be more than previous
	 * 
	 * @param prevWndCount
	 *            - number of previous
	 */
	public void waitForNewWindow(final int prevWndCount) {
		final int wndCount = prevWndCount;
		WebDriverWait wait = new WebDriverWait(driver, 300);
		try {
			wait.until((ExpectedCondition<Boolean>) new ExpectedCondition<Boolean>() {
				public Boolean apply(final WebDriver d) {
					return d.getWindowHandles().size() > wndCount;
				}
			});
		} catch (Exception e) {
			Reporter.log("New window not appeared..", true);
		}
	}

	/**
	 * Select the previous window (the list of handlers)
	 */
	public void selectPreviousWindow() {
		Object[] handles = driver.getWindowHandles().toArray();
		String handle = driver.getWindowHandle();
		Assert.assertTrue(handles.length > 1);
		for (int i = 1; i < handles.length; i++) {
			if (handles[i].equals(handle)) {
				driver.switchTo().window((String) handles[i - 1]);
				return;
			}
		}
		driver.switchTo().window((String) handles[handles.length - 2]);
	}

	/**
	 * Select the first window (the list of handlers)
	 */
	public void selectFirstWindow() {
		Object[] handles = driver.getWindowHandles().toArray();
		driver.switchTo().window((String) handles[0]);
	}

	/**
	 * We expect the emergence of the new window and select it
	 */
	public void selectNewWindow() {
		Object[] handles = driver.getWindowHandles().toArray();
		waitForNewWindow(handles.length);
		handles = driver.getWindowHandles().toArray();
		driver.switchTo().window((String) handles[handles.length - 1]);
	}

	/**
	 * Select the last window (the list of handlers)
	 */
	public void selectLastWindow() {
		Object[] handles = driver.getWindowHandles().toArray();
		driver.switchTo().window((String) handles[handles.length - 1]);

	}

	/**
	 * Go to the home page
	 */
	public void openStartPage(String URL) {
		driver.navigate().to(URL);
	}

	/**
	 * maximizes the window
	 * <p>
	 * works on IE7, IE8, IE9, FF 3.6
	 */
	public void windowMaximise() {
		try {
			((JavascriptExecutor) driver).executeScript(
					"if (window.screen) {window.moveTo(0, 0);window.resizeTo(window.screen.availWidth,window.screen.availHeight);};");
			driver.manage().window().maximize();
		} catch (Exception e) {
			// A lot of browsers crash here
		}
	}

	/**
	 * Navgates to the Url
	 * 
	 * @param url
	 *            Url
	 */
	public void navigate(final String url) {
		driver.navigate().to(url);
	}

	/**
	 * Refresh page.
	 */
	public void refresh() {
		driver.navigate().refresh();
		Reporter.log("Page was refreshed.", true);
	}

	/**
	 * Open new window by hot keys Ctrl + N, webdriver switch focus on it.
	 */
	public void openNewWindow() {
		driver.findElement(By.xpath("//body")).sendKeys(Keys.CONTROL, "n");
		Object[] headers = driver.getWindowHandles().toArray();
		driver.switchTo().window(headers[headers.length - 1].toString());
	}

	/**
	 * click and switch to new window. (works on IE also)
	 * 
	 * @param element
	 *            element
	 */
	public void clickAndSwitchToNewWindow(final WebElement element) {
		Set<String> existingHandles = driver.getWindowHandles();
		element.click();

		String foundHandle = null;
		long endTime = System.currentTimeMillis() + SLEEP_SWITCH;
		while (foundHandle == null && System.currentTimeMillis() < endTime) {
			Set<String> currentHandles = driver.getWindowHandles();
			if (currentHandles.size() != existingHandles.size()) {
				for (String currentHandle : currentHandles) {
					if (!existingHandles.contains(currentHandle)) {
						foundHandle = currentHandle;
						Reporter.log("new window was found", true);
						break;
					}
				}

			}

			if (foundHandle == null) {
				try {
					Thread.sleep(SLEEP_THREAD_SLEEP);
				} catch (InterruptedException e) {
					Reporter.log("new window not found", true);
					e.printStackTrace();
				}
			}
		}
		if (foundHandle != null) {
			driver.switchTo().window(foundHandle);
		} else {
			Reporter.log("new window not found", true);
		}
	}

	/**
	 * Trigger
	 * 
	 * @param script
	 *            script
	 * @param element
	 *            element
	 */
	public void trigger(final String script, final WebElement element) {
		((JavascriptExecutor) driver).executeScript(script, element);
	}

	/**
	 * Executes a script
	 * 
	 * @note Really should only be used when the web driver is sucking at
	 *       exposing functionality natively
	 * @param script
	 *            The script to execute
	 * @return Object
	 */
	public Object trigger(final String script) {
		return ((JavascriptExecutor) driver).executeScript(script);
	}

	/**
	 * Opens a new tab for the given URL (doesn't work on IE)
	 * 
	 * @param url
	 *            The URL to
	 */
	public void openTab(final String url) {
		String script = "var d=document,a=d.createElement('a');a.target='_blank';a.href='%s';a.innerHTML='.';d.body.appendChild(a);return a";
		Object element = trigger(String.format(script, url));
		if (element instanceof WebElement) {
			WebElement anchor = (WebElement) element;
			anchor.click();
			trigger("var a=arguments[0];a.parentNode.removeChild(a);", anchor);
		} else {
			throw new JavaScriptException(element, "Unable to open tab", 1);
		}
	}

	/**
	 * Executes Java Scipt
	 * 
	 * @param script
	 *            Java Script
	 */
	public void jsExecute(final String script) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(script);
	}

	/**
	 * Set cookies into a webdriver instanse.
	 * 
	 * @param cookies
	 *            list
	 */
	public void setCookies(List<Cookie> cookies) {
		for (Cookie cookie : cookies) {
			driver.manage().addCookie(cookie);
		}
	}

	/**
	 * Get All cookies collection.
	 * 
	 * @return
	 */
	public Set<Cookie> getCookies() {
		return driver.manage().getCookies();
	}

	/**
	 * Gets current URL
	 * 
	 * @return current URL
	 */
	public String getLocation() {
		return driver.getCurrentUrl();
	}

	/**
	 * This method will do focus on web element using JavascriptExecutor.
	 * 
	 * @param element
	 */
	public void focusViaJS(WebElement element) {
		logger.info("Scroll to View element");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	/**
	 * This method will do scroll down the page and focus on button
	 */
	public void focusBottom() {
		logger.info("Scroll to page bottom");
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,"
				+ "document.body.scrollHeight,document.documentElement.clientHeight));");
	}

	/**
	 * scroll up
	 */
	public void scrollUp() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(250, 0)"); // x value '250' can be altered
	}

	/**
	 * scroll down
	 */
	public void scrollDownJS() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 250)"); // x value '250' can be altered
	}

	/**
	 * Scroll bottom of the Page
	 */
	public void scrollBottomOfThePage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript(
				"window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight));");
	}

	/**
	 * Scroll bottom of the Page using Actions class
	 */
	public void scrollBottomOfThePageThrActions() {
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
	}

	/**
	 * Full scroll to bottom in slow motion.
	 * 
	 * @throws InterruptedException
	 */
	public void scrollFullToBottom() throws InterruptedException {
		for (int second = 0;; second++) {
			if (second >= 60) {
				break;
			}
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
			Thread.sleep(3000);
		}
	}

	/**
	 * Full scroll to bottom in slow motion using Javascript
	 * 
	 * @throws InterruptedException
	 */
	public void scrollFullToBottomJS() throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		for (int second = 0;; second++) {
			if (second >= 60) {
				break;
			}
			jse.executeScript("window.scrollBy(0,800)", "");
			Thread.sleep(3000);
		}
	}

	/**
	 * Scroll automatically to your WebElement
	 */
	public void scrollToWebelement() {
		WebElement element = driver.findElement(By.xpath("Value"));
		Coordinates coordinate = ((Locatable) element).getCoordinates();
		coordinate.onPage();
		coordinate.inViewPort();
	}

	/**
	 * Page scroll down through java script.For down increase y-axis
	 */
	public void scrollDown() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,200)", "");
		driver.findElement(By.xpath("")).sendKeys(Keys.PAGE_DOWN);

	}

	public String captureScreenshot(String screenshotFlag) {
		String val=null;
		if(screenshotFlag.contains("true"))
		{
			Date d = new Date();
			String date = d.toString().replaceAll(" ", "_");
			date = date.replaceAll(":", "_");
			date = date.replaceAll("\\+", "_");
			System.getProperty("line.separator");

			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File reportPath = new File(result_FolderName);
			if (!reportPath.exists()) {
				if (!reportPath.mkdirs()) {
					throw new RuntimeException("Failed to create screenshot directory");
				}
			}

			// try {

			// FileUtils.cleanDirectory(new File(System.getProperty("user.dir")
			// +"/"+IConstants.SCREENSHOTS_LOCATION ));

			// } catch (IOException e1) {

			// e1.printStackTrace();

			// }
			String xx= getTime()+ "_screenshot.png";
			String f = result_FolderName + "/" + xx;
			File dest = new File(f);
			try {
				FileUtils.copyFile(scrFile, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}
			StringBuilder href = new StringBuilder();
			val = href
					.append("<div><a HREF='" + xx + "'><img src='" + xx
							+ "' alt='Screen Shot' style='width:250px;height:200px'>Link to Screeshot</a></div>")
					.toString();
		}else {
			val=".";
		}
		return val;
	}

	public String getExecutionTime() {

		Date d = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("MMM_dd_HH_mm_ss");
		//System.out.println("Current Date: " + ft.format(d));
		return ft.format(d);

	}

	public String getTime() {

		Date d = new Date();
		String date = d.toString().replaceAll(" ", "_");
		date = date.replaceAll(":", "_");
		date = date.replaceAll("\\+", "_");
		//System.out.println(date.toString());

		return date.toString();

	}

	public void  authenticateApp(String userName,String pwd) throws AWTException, InterruptedException
	{
		robot.setAutoDelay(40);
		robot.setAutoWaitForIdle(true);
		robot.delay(4000);
		robot.mouseMove(40, 130);
		robot.delay(500);
		leftClick();
		robot.delay(500);
		leftClick();
		robot.delay(500);
		type(userName);
		robot.mouseMove(40, 160);
		robot.delay(500);
		leftClick();
		robot.delay(500);
		leftClick();
		robot.keyPress(KeyEvent.VK_TAB);
		robot.delay(500);
		robot.keyRelease(KeyEvent.VK_TAB);
		type(pwd);
		robot.delay(50);
		//Thread.sleep(10000);
		//type(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.delay(250);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.delay(1000);
		// System.exit(0);
	}

	private void leftClick()
	{
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.delay(200);
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
		robot.delay(200);
	}

	private void type(int i)
	{
		robot.delay(40);
		robot.keyPress(i);
		robot.keyRelease(i);
	}

	private void type(String s)
	{
		byte[] bytes = s.getBytes();
		for (byte b : bytes)
		{
			int code = b;
			// keycode only handles [A-Z] (which is ASCII decimal [65-90])
			if (code > 96 && code < 123) code = code - 32;
			robot.delay(40);
			robot.keyPress(code);
			robot.keyRelease(code);
		}
	}

	public void waitForEnterAuthCred(String userName, String pwd) throws AWTException, InterruptedException {

		tillWindowLoad(30);
		Thread.sleep(4000);
		authenticateApp(userName, pwd);
	}

	public static void tillWindowLoad(int time)
	{


		String url = null;

		for(int i=0;i<time;i++)
		{
			try{
				url=driver.getCurrentUrl();
				if(url.equalsIgnoreCase("http://coeapriso.electrolux-na.com/apriso/apriso/#/search"))
					break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}


		}
		//return ele;

	}

	public static WebElement isElementDisplayed(WebDriver driver,WebElement ele,int time)
	{
		//time=1;
		for(int i=0;i<time;i++)
		{
			try{
				Thread.sleep(1000);
				ele.isDisplayed();
				//System.out.println(ele+ " :: Element displayed");
				break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
					ele.isDisplayed();
					break;
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}


		}
		return ele;

	}

	public void switchToFrame(By by,int time)
	{
		//WebElement ele = null;
		for(int i=0;i<time;i++)
		{
			try{

				driver.switchTo().frame(driver.findElement(by));
				break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}


		}
		//return ele;

	}

	public static WebElement isElementDisplayed(By by,int time)
	{
		WebElement ele = null;
		for(int i=0;i<time;i++)
		{
			try{
				ele = driver.findElement(by);
				break;
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(1000);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear on DOM");
				}
			}


		}
		return ele;

	}
	public void waitTillCondition(By by, int time){
		WebDriverWait wait = new WebDriverWait(driver, time); 
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(by));
		//element.click();
	}

	public void waitTillElementDisappears(By by, int time){
		WebDriverWait wait = new WebDriverWait(driver, 150); 
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
			Predicate<WebDriver> pageLoaded = new Predicate<WebDriver>() {
	        @Override
	        public boolean apply(WebDriver input) {
	            return ((JavascriptExecutor) input).executeScript("return document.readyState").equals("complete");
	        }

	    };
		// wait.until(pageLoaded);
		/*wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				System.out.println("Current Window State :"+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
				return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")).equals("complete");
			}
		});*/
	}


	public static int generateRandomIntIntRange(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	public String[] splitValues(String text, String seperator) {

		String [] splits = text.split(seperator);
		return splits;

	}
	public void highLighterMethod(WebDriver driver, WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		System.out.println("Highlighted the element");
	}

	public static String previousDateString(String dateString)
			throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date myDate = dateFormat.parse(dateString);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(myDate);
		calendar.add(Calendar.DAY_OF_YEAR, -1);

		Date previousDate = calendar.getTime();
		String result = dateFormat.format(previousDate);

		return result;
	}

	//validate sharedNC status
	public String validateSharedWC(String wc, String[][] sharedWCRule) {
		String flag = null;

		for(int p=0;p<sharedWCRule.length;p++) {

			if(wc.contains(sharedWCRule[p][0].trim().toLowerCase())) {
				flag=sharedWCRule[p][1];
				break;
			}else {
				flag="nonShared";
			}
		}

		return  flag;
	}
	public static String DateString(String dateString)
			throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		Date myDate = dateFormat.parse(dateString);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(myDate);
		calendar.add(Calendar.DAY_OF_YEAR, 0);

		Date previousDate = calendar.getTime();
		String result = dateFormat.format(previousDate);

		return result;
	}
	// get array index of active workcenter
	
	public int getActiveLineArrayIndex(String[][] LineActiveStatus,String value) {

        int k=0;
        for(int i=0;i<LineActiveStatus.length;i++){
            if((LineActiveStatus[i][0].contains(value))&&(LineActiveStatus[i][1].equalsIgnoreCase("Active"))){
                k=i+1;
                break;
            }
        }
    return k;
}
}