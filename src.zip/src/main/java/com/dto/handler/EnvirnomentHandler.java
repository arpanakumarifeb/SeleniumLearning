package com.dto.handler;

import com.dto.Envirnoment;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import org.testng.Reporter;

public class EnvirnomentHandler
{
  private static EnvirnomentHandler _instance;
  private static InputStream in;
  private static Properties envs = new Properties();
  private static Envirnoment env = null;

  public static EnvirnomentHandler getInstance() {
    if (_instance == null) {
      _instance = new EnvirnomentHandler();
    }
    return _instance;
  }

  public static Envirnoment getEnvirnoment()
  {
    if (env == null) {
      env = new Envirnoment();
      env.setPassword(envs.getProperty("password"));
      env.setUserName(envs.getProperty("username"));
      env.setUrl(envs.getProperty("url"));
      Reporter.log("ENV NAME::::" + envs.getProperty("browser"), true);
      env.setBrowser(envs.getProperty("browser"));
      env.setLocal(Boolean.parseBoolean(envs.getProperty("islocal")));
      env.setChannel(envs.getProperty("channel"));
      env.setGridURL(envs.getProperty("gridurl"));
      env.setTestdroid(Boolean.parseBoolean(envs.getProperty("isTestdroid")));
      env.setTestdroiduser(envs.getProperty("testdroiduser"));
      env.setTestdroidpass(envs.getProperty("testdroidpass"));
      env.setTestdroidproj(envs.getProperty("testdroidproj"));
      env.setLocale(envs.getProperty("locale"));
      env.setEnv(envs.getProperty("env"));
      env.setDeviceType(envs.getProperty("deviceType"));
      env.setFboauthToken(envs.getProperty("fboauthToken"));

      env.setTwittertoken(envs.getProperty("twitter.oauthToken"));
      env.setTwitterSecretToken(envs.getProperty("twitter.secretToken"));
      env.setTwitterConsumerkey(envs.getProperty("twitter.consumerKey"));
      env.setTwitterConsumerSecretKey(envs.getProperty("twitter.consumerSecretKey"));
    }

    return env;
  }

  static
  {
    try
    {
      in = new FileInputStream(System.getProperty("user.dir") + "/" + "src/test/resources/env.properties");

      envs.load(in);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}