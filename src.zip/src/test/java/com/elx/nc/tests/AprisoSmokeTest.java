package com.elx.nc.tests;

import java.awt.AWTException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import org.openqa.selenium.Dimension;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.common.Common;
import com.common.ExcelManager;
import com.common.RetryAnalyzer;
import com.framework.base.SeleniumDriverUtil;
import com.helper.ReadConfig;
import com.relevantcodes.extentreports.LogStatus;
import com.web.pages.WebPageFactory;
import com.web.pages.WebTestCase;

import jxl.read.biff.BiffException;

/**
 * JCREW OMNITURE VERIFICATION class
 */
public class AprisoSmokeTest extends WebTestCase {
	private SeleniumDriverUtil selenium = new SeleniumDriverUtil();
	HashMap<String, String> map = new HashMap<String, String>();
	private Common common = new Common(driver);
	ExcelManager ex = new ExcelManager();
	ReadConfig testData = new ReadConfig();
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(AprisoSmokeTest.class.getName());
	private String url = null;
	String ScreenshotRequire = null;
	String WantToCleanAndRun=null;


	@BeforeMethod(alwaysRun = true)
	public void initialize(ITestContext testContext) {
		driver = selenium.getDriver();
		System.out.println("driver..>" + driver);
		setDriver(driver);
		pageFactory = new WebPageFactory(driver);
		common = new Common(driver);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		testContext.setAttribute("driver", driver);
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().setSize(new Dimension(1980,1080));
		System.out.println("browser size after full screen" + driver.manage().window().getSize());
		url = testContext.getCurrentXmlTest().getParameter("URL");
		test.log(LogStatus.INFO,"Testing URL:" + url);
		ScreenshotRequire = testContext.getCurrentXmlTest().getParameter("ScreenShotRequire");
		WantToCleanAndRun = testContext.getCurrentXmlTest().getParameter("WantToCleanAndRun");
		getDriver().get(url);
		getDriver().manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	}
	//***************************************************************************************************************************************
	// * NAME 			: ValidateEmployeeFUnctionalities
	// * DESCRIPTION 	: ValidateEmployeeFUnctionalities 
	// * AUTHOR			: Arpana
	// * DATE 			: 14th June 2021
	//***************************************************************************************************************************************
	@Test(retryAnalyzer = RetryAnalyzer.class,dataProvider = "inputdata",testName = "ValidateEmployeeFunctionalities", description = "ValidateEmployeeFunctionalities",enabled = true, groups = {
			"", "NC", "LOCAL" ,"AssemblyLines","All" })
	public void ValidateEmployeeFunctionalities(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		try {
			getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("UserName"),testData.getConfig().getProperty("Password"),ScreenshotRequire);
			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem("Employee Skill Maintenance",ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for Employee SKILL option and click");			
			getPageFactory().getSkillMaintenenceScreen().validateEmpScreen("TRN_SKILL_MAINTENANCE",ScreenshotRequire);
			getPageFactory().getSkillMaintenenceScreen().clickAddBtn(ScreenshotRequire);
			String employeeSkillName= getPageFactory().getSkillMaintenenceScreen().addEmployeeSkillFunction(ScreenshotRequire);
			if(employeeSkillName!=null) {
				test.log(LogStatus.INFO, "*********Validated Add skill functionalities sucessfully *******" );
				String modifySkillName= getPageFactory().getSkillMaintenenceScreen().modifyEmployeeSkillFunction(employeeSkillName,ScreenshotRequire);
				if(modifySkillName!=null) {
					test.log(LogStatus.INFO, "*********Validated Modify skill functionalities sucessfully *******" );
					boolean deleteSkillflag= getPageFactory().getSkillMaintenenceScreen().deleteEmployeeSkillFunction(modifySkillName,ScreenshotRequire);
					if(deleteSkillflag) {
						test.log(LogStatus.INFO, "*********Validated Delete skill functionalities sucessfully *******" );
					}else {
						test.log(LogStatus.INFO, "*********Add skill functionalities not working *******" );
					}
				}else {
					test.log(LogStatus.INFO, "********* Modify skill functionalities not working *******" );
				}

			}else {
				test.log(LogStatus.INFO, "********* Add skill functionalities not working *******" );
			}
			getDriver().navigate().refresh();
			Thread.sleep(5000);
			getPageFactory().getElxLogin().userLogout(ScreenshotRequire);

		}catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
	}

	//***************************************************************************************************************************************
	// * NAME 			: ValidateEmployeeSkillPageTitle
	// * DESCRIPTION 	: ValidateEmployeeSkillPageTitle 
	// * AUTHOR			: Arpana
	// * DATE 			: 14th June 2021
	//***************************************************************************************************************************************
	@Test(dataProvider = "inputdata",testName = "ValidateEmployeeSkillPageTitle", description = "ValidateEmployeeSkillPageTitle",enabled = true, groups = {
			"All" })
	public void ValidateEmployeeSkillPageTitle(Hashtable<String, String> data) throws InterruptedException, AWTException, IOException, BiffException {
		String screenshot = null;
		try {
			getPageFactory().getElxLogin().clickLoginToDelmia(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().standardLoginsecondex(ScreenshotRequire);
			screenshot = getPageFactory().getElxLogin().loginToElx(testData.getConfig().getProperty("UserName"),testData.getConfig().getProperty("Password"),ScreenshotRequire);
			getPageFactory().getSearchPage().clickOnDelmiaAprisoPortalItem("Employee Skill Maintenance",ScreenshotRequire);
			test.log(LogStatus.INFO, "Searched for Employee SKILL option and click");			
			getPageFactory().getSkillMaintenenceScreen().validateEmpScreen("TRN_MAINTENANC",ScreenshotRequire);
			getDriver().navigate().refresh();
			Thread.sleep(5000);
			getPageFactory().getElxLogin().userLogout(ScreenshotRequire);
			

		}catch(Exception e1){

			WebTestCase.getTest().log(LogStatus.FAIL,
					e1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(e1.getMessage());
		}
	}




	@AfterMethod
	public void AfterMethodCleanUp(ITestContext testContext)
	{
		getDriver().manage().deleteAllCookies();
	}

}
