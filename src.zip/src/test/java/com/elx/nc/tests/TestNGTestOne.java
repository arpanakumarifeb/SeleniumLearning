package com.elx.nc.tests;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
public class TestNGTestOne {
  	
  	WebDriver driver;
  	int count;
  	@BeforeClass
  	 public void initialize() {
  	     count = 0;
  	  }
  	
  	@BeforeMethod
    public void beforeMethod() {
    	  System.out.println("Starting the browser session");
    }
  	
  	@Test(invocationCount = 3)
  	public void verifyGoogle() throws InterruptedException {
  	  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\main\\resources\\exe\\windowsdriver\\chromedriver.exe");
  	  driver = new ChromeDriver();
  	  String url = "https://www.google.com";
  	  driver.get(url);
  	  String expectedTitle = "Google";
  	  String actualTitle = driver.getTitle();
  	  Assert.assertEquals(actualTitle, expectedTitle);
  	  System.out.println("actualTitle:: " + actualTitle);
  	  count++;
  	  System.out.println("Current Invocation count "+count);
  	  
    }
  
 
  @AfterMethod
  public void afterMethod() throws InterruptedException {
  	  System.out.println("Closing the browser session");
  	  driver.quit();
  	  Thread.sleep(3600000);
 	 System.out.println("wait for 3600000 milisec ");
  }
}